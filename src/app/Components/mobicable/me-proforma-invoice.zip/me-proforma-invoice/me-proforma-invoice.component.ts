/*
____________________________________________________________________________________________________________
## COMPONENT OBJECT FOR Proforma Invoice ##
------------------------------------------------------------------------------------------------------------
|   VERSION     |   1.0      |   CREATED_ON  |   24-JAN-2018 |   CREATED_BY  |   THAPAS
------------------------------------------------------------------------------------------------------------
## COMPONENT FUNTIONALITY DETAILS 	##
------------------------------------------------------------------------------------------------------------
|   ++ HTTP Service for user profile retrieval
|   ++ Ability to add balance/credit for a customer
|   
------------------------------------------------------------------------------------------------------------
## CHANGE LOG DETAILS 				##
------------------------------------------------------------------------------------------------------------
|   ++ 24-JAN-2018    v1.0     - Created the New Component.
|   ++
____________________________________________________________________________________________________________

*/
// -- @details : Built and Custom Imports  #################################################################
//  ~ Start  -----------------------------------------------------------------------------------------------
// Import Angular Core Libraries/Functionalities
import { Component, OnInit, Input } from '@angular/core';
import { MeCallHttpGetService } from '../../../Service/me-call-http-get.service';
import { PersistenceService } from 'angular-persistence';
import { ActivatedRoute } from '@angular/router';
import { IPageChangeEvent } from '@covalent/core/paging';
import { TdDataTableService, TdDataTableSortingOrder, ITdDataTableSortChangeEvent, ITdDataTableColumn } from '@covalent/core/data-table';

// Import Custom Libraries/Functionalities/Services
import { MeUserProfileService } from '../../../Service/me-user-profile.service';
import { StorageType } from "../../../Service/Interfaces/storage-type.enum";
import * as moment from 'moment';
// import * as jsPDF from 'jspdf';

declare var jQuery: any;
declare var $     : any;
declare var M: any;
declare var jsPDF: any; // Important


//  ~ End  -------------------------------------------------------------------------------------------------

@Component({
  selector: 'app-me-proforma-invoice',
  templateUrl: './me-proforma-invoice.component.html',
  styleUrls: ['./me-proforma-invoice.component.css']
})
export class MeProformaInvoiceComponent implements OnInit {

 // -- @details : Class variable declaration ###################################################################
  //  ~ Start - variable declaration _____________________________________________________________________________

  // Class Local variables
 // All variables used within the class must be private

 @Input() setCustNumObj: any;
 private _customerDetails_obj   : any;
 private getRequestInput        : any = "";
 private _userLogin             : any;
 private _userProfileData       : any;
 private currentDate              = new Date().toString();
private presentDate                = new Date().toLocaleString();

 private _latestBill   : any;
 customer_meta : any;


 private postRequestCustomerObject: any =

 {
   records: [{

       owner_id: null,
       customer_number: null,
   }]
 };

 private customer_params : any = {
  "customer_number" : null,
  "owner_id": null
}; 

  rent_amount            : any = "";
  totalTax               : any = "";
  billAmount             : any = "";
  rebateAmount           : any = "";
  previousDue            : any = "";
  collectionAmountDisplay: any = "";


 // Local Variables
 showNoRecords         :boolean=true;
 showLoader   : boolean = true;

 _BillHistory  :any=[];
 customer_number_param : any     = "";
 owner_meta_Json:any;
 billDetailsList : any    = [];
 bill_date        : any;
 customerObject   : any;
 month            : any;
 billMonth        : any = "";
  billDate        : any = "";
  serial           : any;
  date             : any;
  subscription : any = "";
  stbNumber : any = "";
  vcNumber : any = "";
  vcNum : any = "";
  vcNums : any = "";
  stb : any = "";
  stbNum : any = "";
  stbs : any = [];
  vcs : any = [];
  dueDate : any = "";

 //Url Variabes
  public id:any;
  public source:string;

 // Tera DataTable Local Fields
 filteredData: any[] = [];
 filteredTotal: number = 0;
 searchTerm: string = '';
 fromRow: number = 1;
 currentPage: number = 1;
 pageSize: number = 50;
 sortBy: string = 'bill_id';
 selectedRows: any[] = [];
 sortOrder: TdDataTableSortingOrder = TdDataTableSortingOrder.Ascending;


//  ~ End  - variable declaration _______________________________________________________________________________



  constructor(
    public  callHttpGet                      : MeCallHttpGetService,
    private customerDetailsPersistenceService: PersistenceService,
    public  userProfileService               : MeUserProfileService,
    public  route                            : ActivatedRoute,
    private _dataTableService: TdDataTableService
 
  ) {
    this.customer_number_param = +this.route.snapshot.params["id"];
   }

//  ~ End -constructor  --------------------------------------------------------------------------------------


// --  @details :  ngOnChanges ##################################################################################
  //  ~ Start -ngOnChanges  ---------------------------------------------------------------------------------------
  // ngOnChanges get updated customerNumber
  
  ngOnChanges(setCustNumObj:any) {
    // console.log('on change',this.setCustNumObj);
    this.customer_number_param = this.setCustNumObj;
    this.filteredData = [];
    this.filteredTotal = 0;


     // Fetch the User Login Details Stored in the Cache
 this._userLogin = this.customerDetailsPersistenceService.get(
  "userLogin",
  StorageType.SESSION
);
console.warn("----------------- performa Invoice User Login ----------------- ");
console.dir(this._userLogin);
// make call to get user profile details
//  ~ Start  -------------------------------------------------------------------------------------------------
this.userProfileService
.makeRequest_UserProfile(this._userLogin)
.subscribe(response => {
this._userProfileData = response;

console.warn(
"----------------- User Profile Response payment ----------------- "
);
console.log(this._userProfileData);
console.log(this._userProfileData.ownerDetails);




this.owner_meta_Json = JSON.parse(this._userProfileData.ownerDetails.owner_meta_value)
console.log(this.owner_meta_Json.enable_gst)
 // Intialize input parameters for get request
 
 
 if(this.setCustNumObj) {

  this.customer_number_param = this.setCustNumObj;
  console.log('this.customer_number_param',this.customer_number_param);



 this.customer_params.customer_number = this.customer_number_param;
 this.customer_params.owner_id = this._userProfileData.ownerDetails.owner_id;
 this.customer_params.owner_company_name = this._userProfileData.ownerDetails.owner_company_name;

// get the Input JSON format for making http request.
this.getRequestInput = this.callHttpGet.createGetRequestRecord(
  this.customer_params
);

   //get customer details -- start -------------------------------------------
   this.callHttpGet
   .makeRequest_GetCustomerDetails(this.getRequestInput)
   .subscribe(response => {

      // Log Response - Remove Later
      console.log(
        "%c ---------------------------- *****  Customer Details Response - ngonInit ***** ---------------------------- ",
        "background: #2196f3;color: white; font-weight: bold; display: block;"
      );
       // assign customer details response to local vairable
       this.customerObject = response.customersDetails;
       console.log(this.customerObject)

       this.callHttpGet. makeRequest_GetCustomerMeta(this.getRequestInput).subscribe(
        response => {
          console.warn("Customer Meta")
          console.log(response)
          this.customer_meta = response;
          console.log(this.customer_meta.customer_meta.GSTIN)
        }
  
      )


    
 
 this.callHttpGet.makeRequest_GetSubscriptionList(this.getRequestInput).subscribe(
  response => {
    console.warn(
      "%c ___________________________ Subscription Response ___________________________",
      "background: #ff9800;color: black; font-weight: bold;"
    );
    console.log(response);
     this.subscription = response;
    // //JSON.stringify(this.subscription);
    console.log(this.subscription);
    // //console.log(this.subscription.subscription_name);
  
    // for(this.packs of this.packName){
    //   console.log(this.packs);
    // }
  

 this.callHttpGet.makeRequest_GetLatestBill(this.getRequestInput).subscribe(
  response => {

      // Log Response - Remove Later
      console.warn(
        "%c ___________________________ Get Latest Bill Response proforma  ___________________________",
        "background: #ff9800;color: black; font-weight: bold;"
      );

      console.log(response);

      this._latestBill = response;

    
      //assign bill summary
      this.billMonth = this._latestBill.billSummary.bill_date;
      this.billDate = this._latestBill.billSummary.bill_date;
        
     

        // assign bill details
        this.billDetailsList = this._latestBill.billDetail;


        // assign totals

        this.previousDue             = this._latestBill.billSummary.previous_due;
        this.rent_amount             = this._latestBill.billSummary.rent_amount;
       
        this.totalTax                = this._latestBill.billSummary.tax_total  | 0 ;
        this.billAmount              = this._latestBill.billSummary.bill_amount;
        this.rebateAmount            = this._latestBill.billSummary.rebate_amount  | 0 ;
        this.collectionAmountDisplay = this._latestBill.billSummary.collection_amount;

        console.log(this.collectionAmountDisplay);
        
        this.serial = JSON.stringify(this.currentDate);
        console.log(this.serial);
        this.date = moment(this.serial).format('MMMM Do YYYY');
        console.log(this.date);

        this.bill_date = moment(this.billDate).format('d-MMM-YYYY');
        this.month = moment(this.billMonth).format('MMMM YYYY');
        console.log(this.month);

      //   this.outstandingAmt = parseFloat(this.collectionAmountDisplay) - parseFloat(this.receivedAmountDisplay);

      //   if (this.outstandingAmt >= 0) {
      //     this.overDue = this.outstandingAmt;
      //   }
      //   else{
      //     this.overDue = this.outstandingAmt * -1;
      //   }
        
       

      // hide loader
      this.showLoader = false;

      $(document).ready(function() {
        M.updateTextFields();
        $('select').select();
        $('.datepicker').datepicker();
        $('.modal').modal({
          dismissible: false,
        });
    });
    this.downloadPdf();

});

//  ~ End - get customer bill details  -------------------------------------------------------------------------------------------------
});
//  ~ End - Subscription List  -------------------------------------------------------------------------------------------------

});   
 
//get customer details -- end -------------------------------------------



}

});
// ~ End  -------------------------------------------------------------------------------------------------


if(this.setCustNumObj) {

this.customer_number_param = this.setCustNumObj;
console.log('this.customer_number_param',this.customer_number_param);

}
else 
{
this.route.queryParams.subscribe(params => {
 this.id = params["id"];
 this.source = params["Source"];
 });
 
 
 this.customer_number_param = +this.id;
// this.postRequestCustomerObject.records[0].customer_number =this.customer_number_param;
console.log('postRequestCustomerObject payment',this.postRequestCustomerObject);      

}


// initialize 
this.postRequestCustomerObject.records[0].owner_id = this._userProfileData.ownerDetails.owner_id;
this.postRequestCustomerObject.records[0].customer_number =this.customer_number_param;
console.log('postRequestCustomerObject payment',this.postRequestCustomerObject);



  }

//  ~ End -ngOnChanges  ---------------------------------------------------------------------------------------




// --  @details :  ngOnInit ##################################################################################
 //  ~ Start -ngOnInit  ---------------------------------------------------------------------------------------
  ngOnInit() {

 // Fetch the User Login Details Stored in the Cache
 this._userLogin = this.customerDetailsPersistenceService.get(
  "userLogin",
  StorageType.SESSION
);
console.warn("----------------- performa Invoice User Login ----------------- ");
console.dir(this._userLogin);
// make call to get user profile details
//  ~ Start  -------------------------------------------------------------------------------------------------
this.userProfileService
.makeRequest_UserProfile(this._userLogin)
.subscribe(response => {
this._userProfileData = response;

console.warn(
"----------------- User Profile Response payment ----------------- "
);
console.log(this._userProfileData);
console.log(this._userProfileData.ownerDetails);




this.owner_meta_Json = JSON.parse(this._userProfileData.ownerDetails.owner_meta_value)
console.log(this.owner_meta_Json.enable_gst)
console.log(this.owner_meta_Json.udf1)
console.log(this.owner_meta_Json.udf2)
 // Intialize input parameters for get request
 
 
 if(this.setCustNumObj) {

  this.customer_number_param = this.setCustNumObj;
  console.log('this.customer_number_param',this.customer_number_param);



 this.customer_params.customer_number = this.customer_number_param;
 this.customer_params.owner_id = this._userProfileData.ownerDetails.owner_id;
 this.customer_params.owner_company_name = this._userProfileData.ownerDetails.owner_company_name;

// get the Input JSON format for making http request.
this.getRequestInput = this.callHttpGet.createGetRequestRecord(
  this.customer_params
);

   //get customer details -- start -------------------------------------------
   this.callHttpGet
   .makeRequest_GetCustomerDetails(this.getRequestInput)
   .subscribe(response => {

      // Log Response - Remove Later
      console.log(
        "%c ---------------------------- *****  Customer Details Response - ngonInit ***** ---------------------------- ",
        "background: #2196f3;color: white; font-weight: bold; display: block;"
      );
       // assign customer details response to local vairable
       this.customerObject = response.customersDetails;


    
 
 this.callHttpGet.makeRequest_GetSubscriptionList(this.getRequestInput).subscribe(
  response => {
    console.warn(
      "%c ___________________________ Subscription Response ___________________________",
      "background: #ff9800;color: black; font-weight: bold;"
    );
    console.log(response);
     this.subscription = response;
    // //JSON.stringify(this.subscription);
    console.log(this.subscription);
    this.stbNumber = this.subscription.subscription.map(function (obj){
      return obj.stb_number;
    });
    console.log(this.stbNumber.length);
    this.vcNumber = this.subscription.subscription.map(function (obj){
      return obj.stb_vc_number;
    });
    console.log(this.vcNumber.length)
  
  

 this.callHttpGet.makeRequest_GetLatestBill(this.getRequestInput).subscribe(
  response => {

      // Log Response - Remove Later
      console.warn(
        "%c ___________________________ Get Latest Bill Response proforma  ___________________________",
        "background: #ff9800;color: black; font-weight: bold;"
      );

      console.log(response);

      this._latestBill = response;

    
      //assign bill summary
      this.billMonth = this._latestBill.billSummary.bill_date;
      this.billDate = this._latestBill.billSummary.bill_date;
        
     

        // assign bill details
        this.billDetailsList = this._latestBill.billDetail;


        // assign totals

        this.previousDue             = this._latestBill.billSummary.previous_due;
        this.rent_amount             = this._latestBill.billSummary.rent_amount;
       
        this.totalTax                = this._latestBill.billSummary.tax_total  | 0 ;
        this.billAmount              = this._latestBill.billSummary.bill_amount;
        this.rebateAmount            = this._latestBill.billSummary.rebate_amount  | 0 ;
        this.collectionAmountDisplay = this._latestBill.billSummary.collection_amount;

        // var js = JSON.stringify(this.collectionAmountDisplay)
        // let toWords = require('to-words');
        // let words = toWords(js, {currency: true});
        // console.log(words)

            
         this.dueDate =  moment().format("12-MMM-YYYY");
         console.log(this.dueDate)

        console.log(this.collectionAmountDisplay);
        
        this.serial = JSON.stringify(this.currentDate);
        console.log(this.serial);
        this.date = moment(this.serial).format('MMMM Do YYYY');
        console.log(this.date);

        this.bill_date = moment(this.billDate).format('d-MMM-YYYY');
        this.month = moment(this.billMonth).format('MMMM YYYY');
        console.log(this.month);

      //   this.outstandingAmt = parseFloat(this.collectionAmountDisplay) - parseFloat(this.receivedAmountDisplay);

      //   if (this.outstandingAmt >= 0) {
      //     this.overDue = this.outstandingAmt;
      //   }
      //   else{
      //     this.overDue = this.outstandingAmt * -1;
      //   }
        
       

      // hide loader
      this.showLoader = false;

      $(document).ready(function() {
        M.updateTextFields();
        $('select').select();
        $('.datepicker').datepicker();
        $('.modal').modal({
          dismissible: false,
        });
    });
    // this.downloadPdf();

});

//  ~ End - get customer bill details  -------------------------------------------------------------------------------------------------
});
//  ~ End - Subscription List  -------------------------------------------------------------------------------------------------

});   
 
//get customer details -- end -------------------------------------------



}

});
// ~ End  -------------------------------------------------------------------------------------------------


if(this.setCustNumObj) {

this.customer_number_param = this.setCustNumObj;
console.log('this.customer_number_param',this.customer_number_param);

}
else 
{
this.route.queryParams.subscribe(params => {
 this.id = params["id"];
 this.source = params["Source"];
 });
 
 
 this.customer_number_param = +this.id;
// this.postRequestCustomerObject.records[0].customer_number =this.customer_number_param;
console.log('postRequestCustomerObject payment',this.postRequestCustomerObject);      

}


// initialize 
this.postRequestCustomerObject.records[0].owner_id = this._userProfileData.ownerDetails.owner_id;
this.postRequestCustomerObject.records[0].customer_number =this.customer_number_param;
console.log('postRequestCustomerObject payment',this.postRequestCustomerObject);




  }


   // --  @details :  downloadPdf ()#######################################################
  //  ~ Start  -------------------------------------------------------------------------------------------------
  
  downloadPdf() { 
    var doc = new jsPDF('p','pt','a4');
    doc.setLineWidth(1.5)
    doc.rect(5,5,584,820)
    doc.rect(5,5,584,10, 'F')
    doc.setFontSize(18)
    var text = `${this.customer_params.owner_company_name}`
    doc.text(text,20,55);
   
    doc.setFontSize(20);
    doc.setFontType('bold')
    doc.text('INVOICE',485,46)
    doc.setFontSize(12)
    doc.text('Address :',20,95)
    doc.setFontType('normal')
    var text1 = `${this._userProfileData.ownerDetails.owner_company_address}`
    var line = doc.splitTextToSize(text1,190)
    doc.text(line,20,110);
    doc.setFontType('bold')
    doc.text('Phone :',20,75);
    doc.setFontType('normal')
    doc.text(`${this._userProfileData.ownerDetails.owner_phone}`,67,75)
    doc.setFontType('bold')
    doc.text('Invoice#',380,85)
    doc.text('Invoice Date',380,105)
    if(this.owner_meta_Json.enable_gst === "Y")
    {
    doc.text('GSTIN#',380,125)
    }
     //   doc.text('GSTIN: GSTIN 57111899',310,50,null,null,'right')
    doc.setFontType('normal')
    doc.text(`${this._latestBill.billSummary.invoice_id}`,480,85)
    doc.text(`${this.bill_date}`,480,105)
    
    doc.rect(20,165,230,20, 'F')
    doc.rect(310,165,263,20, 'F')
    doc.setTextColor(255,255,255)
    doc.setFontType('normal')
    doc.text('Bill To',25,179)
    doc.text('Details',315,179)
    
    doc.setFontType('bold')
    doc.setTextColor(0,0,0)
    doc.text(`${this.customerObject[0].full_name}`, 25, 200)
    doc.text('Phone :',25,216);
    doc.setFontType('normal')
    doc.text(`${this.customerObject[0].phone}`,72,216)
    if(this.customer_meta.customer_meta.GSTIN != "" && this.customer_meta.customer_meta.GSTIN != null)
    {
      doc.setFontType('bold')
      doc.text('GSTIN :',25,232) 
      doc.setFontType('normal')
      doc.text(`${this.customer_meta.customer_meta.GSTIN}`,72,232)
    }
    doc.setFontType('bold')
    doc.text(`Address :`,25, 248)
    doc.setFontType('normal')
    var text2 = `${this.customerObject[0].address1}`
    var lines = doc.splitTextToSize(text2, 190)
    doc.text(lines,25, 263)
    doc.setFontType('bold')
    

    doc.setFontType('bold')
    doc.text(`Customer ID`,315,200)
    doc.text(`Bill Month`,315,216)
    if(this.owner_meta_Json.due_date != ""){
      doc.text(`Due Date`,315,231)
      doc.setFontType('normal')
      doc.text(`${this.dueDate}`,410,231)
    }
    doc.setFontType('bold')
    doc.text('VC Number', 315, 247)
    for(var vcno of this.vcNumber){
      console.log('outvcno',vcno)
      if( vcno != "None" && vcno != "null" && vcno != null && vcno != "none"){
        console.log('vcno',vcno)
        this.vcs.push(vcno)
        console.log(this.vcs)
      }
    }
    if(this.vcs.length > 1)
    {
      doc.setFontType('normal')
      this.vcNum = this.vcs.slice(0,1)
      this.vcNums = this.vcNum.concat('...')
      var vc = `${this.vcNums}`
      var line3 = doc.splitTextToSize(vc,128)
      doc.text(line3,410,247)
    }
    else{
      doc.setFontType('normal')
      var vc = `${this.vcs}`
      var line3 = doc.splitTextToSize(vc,128)
      doc.text(line3,410,247)
    }
   
   
    doc.setFontType('bold')
    doc.text('STB Number', 315, 263)
    for(var stbno of this.stbNumber){
      console.log('outstbno',stbno)
      if( stbno != "None" && stbno != "null" && stbno != null && stbno != "none"){
        console.log('indstbno',stbno)
        this.stbs.push(stbno)
        console.log(this.stbs)
      }
    }
    console.log(this.stbs)

    if(this.stbs.length > 1)
    {
        doc.setFontType('normal')
        this.stb = this.stbs.slice(0,1)
        console.log(this.stb)
        this.stbNum = this.stb.concat('...')
        var text2 = `${this.stbNum}`
        var line2 = doc.splitTextToSize(text2,128)
        doc.text(line2,410,263)  
    }
     else{
          doc.setFontType('normal')
          var text2 =`${this.stbs}`
          var line2 = doc.splitTextToSize(text2,128)
          doc.text(line2,410,263)
    }
    doc.setFontType('normal')
    doc.text(`${this.customerObject[0].customer_id}`,410, 200)
    doc.text(`${this.month}`,410,216)

    doc.setLineWidth(0.5)
    doc.line(20, 295, 571, 295)
    doc.setFontSize(18);
    doc.setFontType('bold')
    doc.text('INVOICE TOTAL',25,320)
    doc.text(`Rs. ${this.collectionAmountDisplay.toFixed(2)}`,520,320,null,null,'right')
    doc.line(20,332,571,332)


    var data = this.subscription.subscription;
    var columns = [
      { title:"#", dataKey: "rownum"},
      { title:"Description",dataKey:"subscription_name"},
      { title:"Amount",dataKey:"total_amount"}
    ]
    var res = doc.autoTable(columns, data,{startX:250,startY: 368,theme:'grid',
    columnStyles: { rownum:{columnWidth:70,halign:'center'},subscription_name:{columnWidth:320}, total_amount: {columnWidth: 125,halign:'right'}},
    headerStyles:{fillColor: [0, 0, 0],halign:'center',fontSize: 12},});
    let first = doc.autoTable.previous.finalY;
    doc.rect(430,first,125,20)
    doc.rect(430,first+20,125,20)
    doc.rect(430,first+40,125,20)
    doc.rect(430,first+60,125,20)
    doc.rect(430,first+80,125,20)
    doc.rect(430,first+100,125,20)
    doc.setFontType('normal')
    doc.setFontSize(10)
    doc.text(`${this.rent_amount.toFixed(2)}`,550,first+14,null,null,'right')
    doc.text(`${this._latestBill.billSummary.cgst_total.toFixed(2)}`,550,first+34,null,null,'right')
    doc.text(`${this._latestBill.billSummary.sgst_total.toFixed(2)}`,550,first+54,null,null,'right')
    doc.text(`${this.billAmount.toFixed(2)}`,550,first+74,null,null,'right')
    doc.text(`${this.rebateAmount.toFixed(2)}`,550,first+94,null,null,'right')
    doc.text(`${this.previousDue.toFixed(2)}`,550,first+114,null,null,'right')
    doc.setFontSize(11)
    doc.text('Sub Total',377,first+14)
    doc.text('CGST[9%]',372,first+34)
    doc.text('SGST[9%]',372,first+54)
    doc.text('Monthly Charge',348,first+74)
    doc.text('Rebate Amount',349,first+94)
    doc.text('Previous Due',359,first+114)
    doc.setFontSize(15);
    doc.setFontType('bold')
    doc.text('Total',385,first+140)
    doc.setFillColor(0, 0, 0)
    doc.rect(429.5,first+120,125.5,30,'F')
    doc.setTextColor(255,255,255)
    doc.text(`${this.collectionAmountDisplay.toFixed(2)}`,550,first+140,null,null,'right')
   

    doc.rect(40,first+40,250,110)
    if(this.owner_meta_Json.udf1 != "" && this.owner_meta_Json.udf2 != "")
    {
      doc.setFontSize(10);
      doc.setFontType('normal')
      doc.setTextColor(0,0,0)
      doc.rect(40,first+120,250,15)
      doc.text(`${this.owner_meta_Json.udf1}`,45,first+131)
      doc.rect(40,first+135,250,15)
      doc.text(`${this.owner_meta_Json.udf2}`,45,first+147)
    }
    doc.setFillColor(0, 0, 0)
    doc.rect(40,first+24,250,20,'F')
    doc.setFontSize(12);
    doc.setFontType('bold')
    doc.setTextColor(255,255,255)
    doc.text('Comments',45,first+38)
    
    doc.setFontSize(15);
    doc.setFontType('normal')
    doc.setTextColor(0,0,0)
    doc.setDrawColor(0,0,0)
    doc.line(20, 790, 571, 790)
    doc.text('Thank You',258,814)
    doc.setFontSize(8);
    doc.setFontType('normal')
    // doc.setTextColor(161,169,169)
    doc.text('**This is a computer generated invoice and does not require any signature',25,837)

    doc.save('Invoice_'+this.customerObject[0].full_name+'_'+this._latestBill.billSummary.customer_id+'_'+this.presentDate+'.pdf');
  }

  //  ~ End  ----------------------------------------------------------------------------------------------------

 // --  @details :  receiveCustomerObject (Emit Event)#######################################################
  //  ~ Start  -------------------------------------------------------------------------------------------------
  receiveCustomerObject($event) {
    // Fetch the Customer Object Value from Event Emitter.
    this.customerObject = $event;

    console.log("**** @@ Customer Object @@ ****");
    console.log(this.customerObject);
    

  }
  //  ~ End  ----------------------------------------------------------------------------------------------------
  
}
