/*
_________________________________________________________________________________________________
## COMPONENT OBJECT FOR COLLECTION REPORT ##
------------------------------------------------------------------------------------------------------------
|   VERSION     |   1.0      |   CREATED_ON  |   07-JUN-2018 |   CREATED_BY  |   THAPAS
------------------------------------------------------------------------------------------------------------
## COMPONENT FUNTIONALITY DETAILS 	##
------------------------------------------------------------------------------------------------------------
|   ++ HTTP Service for user profile retrieval
|   ++ Get the data of all users for the owner
|   ++ Render the Collection data in tabular format with ability to :-
|      ** Ability to Filter by Area
|      ** Ability to Filter by User
|    
------------------------------------------------------------------------------------------------------------
## CHANGE LOG DETAILS 				##
------------------------------------------------------------------------------------------------------------
|   ++ 07-JUN-2018    v1.0     - Created the New Component.
|   ++
____________________________________________________________________________________________________________

*/

// -- @details : Built and Custom Imports  #################################################################
//  ~ Start ________________________________________________________________________________________________
// Import Angular Core Libraries/Functionalities

import { Component, OnInit, NgZone, Input } from "@angular/core";
import { PersistenceService } from "angular-persistence";
import { Router,NavigationExtras } from "@angular/router";
import { IPageChangeEvent } from '@covalent/core/paging';
import { TdDataTableService, TdDataTableSortingOrder, ITdDataTableSortChangeEvent, ITdDataTableColumn } from '@covalent/core/data-table';
import {
  FormBuilder,
  FormGroup,
  AbstractControl,
} from "@angular/forms";
import {
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatRippleModule,
  MatSnackBarModule,
  MatSortModule,
  MatSnackBar,
  MatAutocompleteModule
} from "@angular/material";

import { startWith  } from "rxjs/operators/startWith";
import { map        } from "rxjs/operators/map";
import { Observable } from "rxjs/Observable";
import * as moment from 'moment';
import { DatePipe } from '@angular/common';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';

// Import Custom Libraries/Functionalities/Services
import { MeCallHttpGetService } from './../../../Service/me-call-http-get.service';
import { MeUserProfileService } from './../../../Service/me-user-profile.service';
import { StorageType } from './../../../Service/Interfaces/storage-type.enum';
import { MeCalculateDateService } from './../../../Service/me-calculate-date.service';
import { MeGzipService } from '../../../Service/me-gzip.service';

// Decimal Format for integer values displayed in tera datatable.
const DECIMAL_FORMAT: (v: any) => any = (v: number) => v.toFixed(2);

// below variables declared for Jquery and Material script
// $ for jQuery functions and M for Material functions
declare var require: any;
declare var jQuery: any;
declare var $: any;
declare var M: any;

//  ~ End__________________________________________________________________________________________________

@Component({
  selector: 'app-me-customer-report',
  templateUrl: './me-customer-report.component.html',
  styleUrls: ['./me-customer-report.component.css']
})
export class MeCustomerReportComponent implements OnInit {

  // -- @details : Class variable declaration ################################################################
  //  ~ Start_________________________________________________________________________________________________

  //-- Create Form Group
  customerListReportFilters: FormGroup;

  //-- Create List of Fields
  area_name: AbstractControl;
  BalanceStatus: AbstractControl;
  
  
  // Class Form variables
  // All variables used in component template ( html file ) must be public
  showLoader   : boolean = true;
  showNoRecords: boolean = false;
  showResult    : boolean = false;
  loadComponentStatus    : boolean = false;
  
  // Class Local variables
  // All variables used within the class must be private
  private getRequestInput    : any   = "";
  private _userProfileData   : any;
  private _userLogin         : any;
  private _customerReportList: any[] = [];
  private _areaList          : any   = [];
  private reportValuesJSON   : any      = null;
  private area_id            : any;
  private reportDefaultObj   : any;
  private customerNumber   : any;
  public selectedTabIndex : number;

  filteredAreas: Observable<any[]>;
  customerReportList_obj : any[] = [];
  exportColumnsData : any[] = [];
  

  // Tera DataTable Local Fields
  filteredData : any[]  = [];
  filteredTotal: number = 0;

  searchTerm  : string                  = '';
  fromRow     : number                  = 1;
  currentPage : number                  = 1;
  pageSize    : number                  = 50;
  sortBy      : string                  = 'customer_id';
  selectedRows: any[]                   = [];
  sortOrder   : TdDataTableSortingOrder = TdDataTableSortingOrder.Ascending;


  private postRequestObject: any   = {
    records: [
      {
        area_id  : "",
        BalanceStatus  : "",
        owner_id : ""
      }
    ]
  };

  // Tera DataTable Set Column name/Label and other features.
  columns: ITdDataTableColumn[] = [
    { name: 'customer_id', label: 'Customer Id',  filter: true,sortable: true, width: 130  },
    { name: 'full_name', label: 'Customer Name',  filter: true,sortable: true, width: 230 },
    { name: 'stb_cnt', label: 'No. of STB',  filter: true, sortable: true, width: 120},
    { name: 'stb_vc_number', label: 'VC #',  filter: true, sortable: false , width: 250},
    { name: 'available_balance', label: 'Available Balance',  filter: true, sortable: true, numeric: true, format: DECIMAL_FORMAT  },
    { name: 'balance_status', label: 'Balance Status',  filter: true, sortable: true },
    { name: 'customer_number', label: 'Action', sortable: false, filter: false }
  ];  

  // function to open left side navgivation bar
  _opened: boolean = false;
 

  //  ~ End___________________________________________________________________________________________________
  
  // --  @details :  constructor ##############################################################################
  //  ~ Start - constructor____________________________________________________________________________________

  constructor(
            fb                      : FormBuilder,
    public  callHttpGet             : MeCallHttpGetService,
    public  userProfileService      : MeUserProfileService,
    private reportPersistenceService: PersistenceService,
    private _dataTableService       : TdDataTableService,
    public  zone                    : NgZone,
    private calculateDate           : MeCalculateDateService,
    public  datepipe                : DatePipe,
    private router                  : Router,
    private gzipService       :MeGzipService,
  ) { 

    /*
      @details -  Intialize the form group with fields
        ++ The fields are set to default values - in below case to - null.
        ++ The fields are assigned validators
            ** Required Validator
    */

   this.customerListReportFilters = fb.group({
    area_name: [""],
    BalanceStatus: [""]
   
  });

  // Controls are used in me-collection-report.component.html for accessing values and checking functionalities
  this.area_name = this.customerListReportFilters.controls["area_name"];
  this.BalanceStatus = this.customerListReportFilters.controls["BalanceStatus"];


  // Subscribe for Area changes to get area_id
  // ~ Start -- Area_name changes ------------------------------------------------
    this.area_name.valueChanges.subscribe((value: string) => {

      for(let area in this._areaList) {

        if(this._areaList[area].area_name === value) {
          this.area_id = this._areaList[area].area_id;
        }
      }
      console.log('area_id',this.area_id);
    });
  // ~End --------------------------------------------------------------------------


  }
//  ~ End - constructor_____________________________________________________________________________________



// --  @details :  ngOnInit ###############################################################################
//  ~ Start - ngOnInit_____________________________________________________________________________________
  ngOnInit() {

    this.filter();
    this.selectedTabIndex = 0;

    //initialize flags
    this.showLoader    = true;
    this.showNoRecords = false;
    this.showResult    = false;

    // initialize and execute jquery document ready
    this.zone.run(() => {
      // https://stackoverflow.com/questions/44919905/how-to-invoke-a-function-within-document-ready-in-angular-4
      // https://angular.io/api/core/NgZone

      $(document).ready(function() {
        $("select").select();
        $("input#input_text, textarea#textarea2").characterCounter();
        $('.modal').modal(
          {
            dismissible: false,
          }
        );
        // intialize input label
        M.updateTextFields();
      });
    });

     // Fetch the User Login Details Stored in the Cache
     this._userLogin = this.reportPersistenceService.get(
      "userLogin",
      StorageType.SESSION
    );


    // make call to get user profile details
    //  ~ Start  --------------------------------------------------------------------------------- 
    this.userProfileService.makeRequest_UserProfile(this._userLogin).subscribe(response => {
      //assign user profile data from the response
       this._userProfileData = response;

      // Log Response - Remove Later
      console.warn(
        "%c ___________________________ UserProfile Response ___________________________",
        "background: #4dd0e1;color: black; font-weight: bold;"
      );
      console.log(this._userProfileData);

      // get the Input JSON format for making http request.
      this.getRequestInput = this.callHttpGet.createGetRequestRecord(
        this._userProfileData.ownerDetails
      );

      console.log(
        "%c  Request Input : >>> ",
        "color: green; font-weight: bold;",
        this.getRequestInput
      );

      // make call for retrieving Area List  
      //  ~ Start  -------------------------------------------------------------------------------------------------
        this.callHttpGet.makeRequest_GetArea(this.getRequestInput).subscribe(response => {
    
          this.gzipService.makeRequest_uncompress(response).then(function(result) {
              
            this._areaList = result.areaList;
          }.bind(this))

        });
      //  ~ End ________________________________________________________________________________________


      // Intialize report Object;
      this.reportDefaultObj = {
          "owner_id":this._userProfileData.ownerDetails.owner_id
        };

      // get the Input JSON format for making http request.
      this.getRequestInput = this.callHttpGet.createGetRequestRecord(
        this.reportDefaultObj
      );

      console.warn(
        "%c ___________________________ getRequestInput ___________________________",
        "background: #9fa8da;color: black; font-weight: bold;"
      );

      console.log('default object is:',this.getRequestInput);
    
      // make call for getCustomerList Report 
      //  ~ Start  ----------------------------------------------------------------------------------
      this.callHttpGet.makeRequest_getCustomerListReport(this.getRequestInput).subscribe(response => {
          
        // Log Response - Remove Later
        // console.warn(
        //     "%c ___________________________ getCustomerList Report Response ___________________________",
        //     "background: #4dd0e1;color: black; font-weight: bold;"
        // );
        // console.log(response);

        this.gzipService.makeRequest_uncompress(response).then(function(result) {
              
          this._customerReportList = result.customersList;

          this.customerReportList_obj = this._customerReportList;

        
          if(this._customerReportList.length > 0  ){

            console.log("----- Customer List Length ----- ", this._customerReportList.length);

            this.filteredData  = this.customerReportList_obj;
            this.filteredTotal = this.customerReportList_obj.length;
            this.filter();

            // set flags
            this.showLoader    = false;
            this.showNoRecords = false;
            this.showResult    = true;
          }
          else 
          {
            // set flags in case of blank reponse or no result.
            this.showLoader    = false;
            this.showNoRecords = true;
            this.showResult    = false;
          }
        }.bind(this))

      });

      // ~ End  -----------------------------------------------------------------------------------------
      
    });

  }
//  ~ End - ngOnInit_____________________________________________________________________________________


  // --  @details :  onSubmit ##################################################################################
  //  ~ Start -onSubmit ________________________________________________________________________________________
  
    onSubmit(value: string): void {
    
    // Show Loader
      this.showLoader    = true;
      this.showResult    = false;
      this.showNoRecords = false;
    
      this.exportColumnsData = [];
          
      console.log(
        "%c Form Submitted Values ***** ----------------------------------------------------------------------- ",
        "background: #689f38;font-weight: bold;color: white; "
      );
      console.log(value);
      
      //create JSON
      this.reportValuesJSON = JSON.parse(JSON.stringify(value));
      // console.log("--------------- JSON Value ---------------");
      // console.log(this.reportValuesJSON);

    // Assign Values from values to post request object
      this.postRequestObject.records[0].area_id   = this.area_id;
      this.postRequestObject.records[0].owner_id  = this._userProfileData.ownerDetails.owner_id;
  
      console.log(
        "%c Post Request Object ***** -------------------------------------------------------------------------- ",
        "background: #8bc34a;font-weight: bold;color: white; "
      );
      console.log(JSON.stringify(this.postRequestObject));

    // make call for getCustomerList Report 
    //  ~ Start  ----------------------------------------------------------------------------------
      this.callHttpGet.makeRequest_getCustomerListReport(this.postRequestObject).subscribe(response => {
        
        // Log Response - Remove Later
        // console.warn(
        //     "%c ___________________________ getCustomerList Report Response ___________________________",
        //     "background: #4dd0e1;color: black; font-weight: bold;"
        // );
        // console.log(response);

        this.gzipService.makeRequest_uncompress(response).then(function(result) {
              
          this._customerReportList = result.customersList;  
          this.customerReportList_obj = this._customerReportList;
          if (this.customerReportList_obj.length > 0) {
            this.showLoader = false;
            this.showNoRecords = false;
            this.filteredData  = this.customerReportList_obj;
            this.filteredTotal = this.customerReportList_obj.length;
    
            this.filter();
    
            // set flags
            this.showLoader    = false;
            this.showNoRecords = false;
            this.showResult    = true;
          } else {
    
            this.customerReportList_obj = [];
            this.filteredData  = this.customerReportList_obj;
            this.filteredTotal = this.customerReportList_obj.length;
    
            // set flags in case of blank reponse or no result.
            this.showLoader    = false;
            this.showNoRecords = true;
            this.showResult    = false;
    
          }
        }.bind(this))
       
      });
  
      // ~ End  -----------------------------------------------------------------------------------------
    
    }
    
  //  ~ End -onSubmit ________________________________________________________________________________________


  // --  @details :  Class Functions for the Component ###################################################
  //  ~ Start_____________________________________________________________________________________________

  // ~ Start ---------------------------------------------------------------
  // -- @details : Function get AreaList for autocomplete.
  getAreaList() {
    this.filteredAreas = this.area_name.valueChanges.pipe(
      startWith(""),
      map(
        areaValue =>
          areaValue ? this.filterAreas(areaValue) : this._areaList.slice()
      )
    );
    console.warn("----------------- filteredAreas ----------------- ");
    console.warn(this.filteredAreas);

  }

  filterAreas(areaValue: string) {
    console.log(
      "%c filterAreas ***** --------------------------------------------------- ",
      "background: #4caf50;font-weight: bold;color: white; "
    );
    console.log(areaValue.toLowerCase());
    
    return this._areaList.filter(
      area =>
        area.area_name.toLowerCase().indexOf(areaValue.toLowerCase()) === 0
    );
  }

  // ~ End ----------------------------------------------------------------


  // ~ Start ---------------------------------------------------------------
  // -- @details : Function for teradata datatable.
  sort(sortEvent: ITdDataTableSortChangeEvent): void {
    this.sortBy = sortEvent.name;
    this.sortOrder = sortEvent.order;
    this.filter();
  }

  search(searchTerm: string): void {
    this.searchTerm = searchTerm;
    this.filter();
  }

  page(pagingEvent: IPageChangeEvent): void {
    this.fromRow = pagingEvent.fromRow;
    this.currentPage = pagingEvent.page;
    this.pageSize = pagingEvent.pageSize;
    this.filter();
  }

  showAlert(event: any): void {
    let row: any = event.row;
    // .. do something with event.row
  }

  filter(): void {
    let newData: any[] = this.customerReportList_obj;
    let excludedColumns: string[] = this.columns
    .filter((column: ITdDataTableColumn) => {
      return ((column.filter === undefined && column.hidden === true) ||
              (column.filter !== undefined && column.filter === false));
    }).map((column: ITdDataTableColumn) => {
      return column.name;
    });
    newData = this._dataTableService.filterData(newData, this.searchTerm, true, excludedColumns);
    this.filteredTotal = newData.length;
    newData = this._dataTableService.sortData(newData, this.sortBy, this.sortOrder);
    newData = this._dataTableService.pageData(newData, this.fromRow, this.currentPage * this.pageSize);
    this.filteredData = newData;
  }
  // ~ End ---------------------------------------------------------------


  // ~ Start ---------------------------------------------------------------
  // -- @details : Function to clear fields on autocomplete for area and agent.
 
  clearAreaNameField() {

    this.customerListReportFilters.controls['area_name'].setValue('');
    this.area_id = '';
  }
  // ~ End ---------------------------------------------------------------


  //  ~ End_____________________________________________________________________________________________

  // --  @details :  receiveToggleSidebarObj (Emit Event)#######################################################
  //  ~ Start  -------------------------------------------------------------------------------------------------

    receiveToggleSidebarObj($event) {
      // Fetch the Customer Object Value from Event Emitter.
      this._opened = $event;

      // console.log("**** @@ Sidebar Open Object @@ ****");
      console.log(this._opened);

    }
  //  ~ End  ----------------------------------------------------------------------------------------------------


  // --  @details :  getCustomerNumber (param)#######################################################
  //  ~ Start  -------------------------------------------------------------------------------------------------

    getCustomerNumber(custNumvalue) {

      this.customerNumber = custNumvalue;
      // console.log('customerNumber',this.customerNumber);
      
      this.loadComponentStatus = true;
      this.selectedTabIndex = 0;

    }
 //  ~ End  ----------------------------------------------------------------------------------------------------


  // --  @details : exportData()#######################################################
  //  ~ Start  -------------------------------------------------------------------------------------------------

  exportData() {
  
    if(this._customerReportList) {

      this._customerReportList.map(item => {
        return {
            customer_id : item.customer_id,
            name: item.full_name,
            phone: item.phone,
            area_name: item.area_name,
            address1: item.address1,
            city: item.city,
            customer_status: item.customer_status,
            debit_till_date: item.debit_till_date,
            credit_till_date: item.credit_till_date,
            available_balance: item.available_balance,
            balance_status: item.balance_status,
            stb_cnt: item.stb_cnt,
            stb_cstb_vc_numbernt: '`' + item.stb_vc_number,
            stb_number: '`' + item.stb_number,
        }
      }).forEach(item => this.exportColumnsData.push(item));
      console.log('exported data',this.exportColumnsData);
      
      const options = { 
        fieldSeparator: ',',
        quoteStrings: '"',
        decimalseparator: '.',
        showLabels: true,
        showTitle: false,
        useBom: false,
        headers: [
          'Customer Id',
          'Full Name',
          'Phone Number',
          'Area Name',
          'Address',
          'City',
          'Customer Status',
          'Debit_Till_Date',
          'Credit_Till_Date',
          'Available Balance',
          'Balance Status',
          'STB Count',
          'VC Number',
          'STB Number'
        ]
      };


      new Angular2Csv(this.exportColumnsData, 'Customers_List', options);
    }
  }
  //  ~ End  ----------------------------------------------------------------------------------------------------

  
// --  @details : EditcustomerLink()#######################################################
  //  ~ Start  -------------------------------------------------------------------------------------------------

  NavigatePaymentLink(link,value) 
  {
   console.log('EditcustomerLink');
   let navigationExtras: NavigationExtras = {
     queryParams: {
         "id": value,
         "Source": "customerreport"
     }
 };
 console.log('navigationExtras',navigationExtras);

 this.router.navigate([link], navigationExtras);
 }


  //  ~ End  ----------------------------------------------------------------------------------------------------

}
// -------------------  Component & Class Definition - End ---------------------------------------------
