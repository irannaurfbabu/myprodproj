import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MeUnpaidReportNewComponent } from './me-unpaid-report-new.component';

describe('MeUnpaidReportNewComponent', () => {
  let component: MeUnpaidReportNewComponent;
  let fixture: ComponentFixture<MeUnpaidReportNewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MeUnpaidReportNewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MeUnpaidReportNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
