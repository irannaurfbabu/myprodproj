/*
_________________________________________________________________________________________________
## COMPONENT OBJECT FOR UNPAID REPORT ##
------------------------------------------------------------------------------------------------------------
|   VERSION     |   1.0      |   CREATED_ON  |   21-MAR-2018 |   CREATED_BY  |   AKASH
------------------------------------------------------------------------------------------------------------
## COMPONENT FUNTIONALITY DETAILS 	##
------------------------------------------------------------------------------------------------------------
|   ++ HTTP Service for user profile retrieval
|   ++ Get the data of all users for the owner
|   ++ Render the Unpaid Customers List in tabular format with ability to :-
|      ** Ability to Filter by Area
|   
------------------------------------------------------------------------------------------------------------
## CHANGE LOG DETAILS 				##
------------------------------------------------------------------------------------------------------------
|   ++ 21-MAR-2018    v1.0     - Created the New Component.
|   ++
____________________________________________________________________________________________________________

*/

// Import Angular Core Libraries/Functionalities/Services
import { Component, OnInit, NgZone } from "@angular/core";
import { FormBuilder, FormGroup, AbstractControl } from "@angular/forms";
import { DatePipe } from "@angular/common";
import { startWith } from "rxjs/operators/startWith";
import { map } from "rxjs/operators/map";
import { Observable } from "rxjs/Observable";

// Import Custom Libraries/Functionalities/Services
import { MeCallHttpGetService } from "./../../../Service/me-call-http-get.service";
import { MeUserProfileService } from "./../../../Service/me-user-profile.service";
import { StorageType } from "./../../../Service/Interfaces/storage-type.enum";
import { MeCalculateDateService } from "./../../../Service/me-calculate-date.service";
import { MeGzipService } from "../../../Service/me-gzip.service";

// Import third party Libraries/Functionalities/Services
import { MatTabChangeEvent } from "@angular/material";
import { MatTabsModule } from "@angular/material/tabs";
import { PaginatorModule } from "primeng/paginator";
import { TableModule } from "primeng/table";
import { PersistenceService } from "angular-persistence";
import * as moment from "moment";
import { Angular2Csv } from "angular2-csv/Angular2-csv";
import * as _ from "lodash";

@Component({
  selector: "app-me-unpaid-report-new",
  templateUrl: "./me-unpaid-report-new.component.html",
  styleUrls: ["./me-unpaid-report-new.component.css"]
})
export class MeUnpaidReportNewComponent implements OnInit {
  // -- @details : Class variable declaration ################################################################
  //  ~ Start_________________________________________________________________________________________________

  //-- Create Form Group
  reportFilter: FormGroup;

  //-- Create List of Fields
  area_name: AbstractControl;
  user_name: AbstractControl;
  toppings: AbstractControl;
  dateRange: AbstractControl;
  fromDate: AbstractControl;
  toDate: AbstractControl;

  // Class Form variables
  // All variables used in component template ( html file ) must be public
  showLoader: boolean = true;
  showNoRecords: boolean = false;
  showResult: boolean = false;

  filteredAreas: Observable<any[]>;
  filteredUsers: Observable<any[]>;

  // function to open left side navgivation bar
  _opened: boolean = false;

  // Class Local variables
  // All variables used within the class must be private
  private getRequestInput: any = "";
  private _userProfileData: any;
  private _userLogin: any;
  private _unpaidReportList: any[] = [];
  private _areaList: any = [];
  private _userList: any = [];
  private reportValuesJSON: any = null;
  private area_id: any;
  private user_id: any;
  private customerNumber: any;

  private reportDate = new Date().toString();
  private getCollectionListAPI_Input: any = {
    records: [
      {
        area_id: "",
        user_id: "",
        owner_id: "",
        submitted_by: "",
        submitted_by_id: "",
        comments: ""
      }
    ]
  };

  // Constructor  ###########################################################################
  //  ~ Start - constructor__________________________________________________________________
  constructor(
    fb: FormBuilder,
    public callHttpGet: MeCallHttpGetService,
    public userProfileService: MeUserProfileService,
    private reportPersistenceService: PersistenceService,
    private calculateDate: MeCalculateDateService,
    public datepipe: DatePipe,
    private gzipService: MeGzipService
  ) {
    this.reportFilter = fb.group({
      area_name: [""],
      user_name: [""]
    });

    // Controls are used in me-collection-report.component.html for accessing values and checking functionalities
    this.area_name = this.reportFilter.controls["area_name"];
    this.user_name = this.reportFilter.controls["user_name"];

    // Subscribe for Area changes to get area_id
    // ~ Start -- Area_name changes ------------------------------------------------
    this.area_name.valueChanges.subscribe((value: string) => {
      for (let area in this._areaList) {
        if (this._areaList[area].area_name === value) {
          this.area_id = this._areaList[area].area_id;
        }
      }
      console.log("area_id", this.area_id);
    });
    // ~End --------------------------------------------------------------------------

    // Subscribe for user_name changes to get user_id
    // ~ Start -- user_name changes ------------------------------------------------
    this.user_name.valueChanges.subscribe((value: string) => {
      for (let user in this._userList) {
        if (this._userList[user].user_name === value) {
          this.user_id = this._userList[user].user_id;
        }
      }
      console.log("user_id", this.user_id);
    });
    // ~End --------------------------------------------------------------------------
  }
  //  ~ End - constructor_____________________________________________________________________________________

  // --  @details :  ngOnInit ###############################################################################
  //  ~ Start - ngOnInit_____________________________________________________________________________________
  ngOnInit() {
    // align flags
    this.showLoader = true;
    this.showNoRecords = false;
    this.showResult = false;

    // Fetch the User Login Details Stored in the Cache
    this._userLogin = this.reportPersistenceService.get(
      "userLogin",
      StorageType.SESSION
    );

    // make call to get user profile details
    //  ~ Start  ---------------------------------------------------------------------------------
    this.userProfileService
      .makeRequest_UserProfile(this._userLogin)
      .subscribe(response => {
        //assign user profile data from the response
        this._userProfileData = response;

        // Log Response - Remove Later
        console.warn(
          "%c ___________________________ UserProfile Response ___________________________",
          "background: #4dd0e1;color: black; font-weight: bold;"
        );
        console.log(this._userProfileData);

        // get the Input JSON format for making http request.
        this.getRequestInput = this.callHttpGet.createGetRequestRecord(
          this._userProfileData.ownerDetails
        );

        console.log(
          "%c  Request Input : >>> ",
          "color: green; font-weight: bold;",
          this.getRequestInput
        );

        // make call for retrieving Area List
        //  ~ Start  -------------------------------------------------------------------------------------------------
        // this.callHttpGet
        //   .makeRequest_GetArea(this.getRequestInput)
        //   .subscribe(response => {
        //     let uncompress = response =>
        //       new Promise((resolve, reject) => {
        //         // let Buffer = require("buffer").Buffer;
        //         // let zlib = require("zlib");

        //         // zlib.gunzip(Buffer.from(response, "base64"), function(
        //         //   err,
        //         //   uncompressedMessage
        //         // ) {
        //         //   if (err) {
        //         //     reject(err);
        //         //   } else {
        //         //     let resultobj = JSON.parse(uncompressedMessage.toString());
        //         //     let resultArray = resultobj.areaList;
        //         //     resolve(resultArray);
        //         //   }
        //         // });

        //       });

        //     uncompress(response).then(
        //       function(areaList) {
        //         console.log(areaList);
        //         console.log("Area Length : ", areaList.length);

        //         this._areaList = areaList;
        //       }.bind(this)
        //     );
        //   });
        //  ~ End ________________________________________________________________________________________

        // make call for retrieving User List
        //  ~ Start  -----------------------------------------------------------------------------------------

        // this.callHttpGet.makeRequest_ManageUser(this.getRequestInput).subscribe(response => {
        //   // Log Response - Remove Later
        //   console.warn(
        //     "%c ___________________________ Manage User Response ___________________________",
        //     "background: #9fa8da;color: black; font-weight: bold;"
        //   );

        //   console.log(response.usersList);
        //   console.log("User Length : ", response.usersList.length);

        //   this._userList = response.usersList;

        // });

        //  ~ End  ---------------------------------------------------------------------------------------------

        // make call for makeRequest_getUnpaidReport
        //  ~ Start  ----------------------------------------------------------------------------------
        this.callHttpGet
          .makeRequest_getUnpaidReport(this.getRequestInput)
          .subscribe(response => {
            this.gzipService.makeRequest_uncompress(response).then(
              function(result) {
                this._unpaidReportList = result.unpaidReport;
                console.log("this._unpaidReportList", this._unpaidReportList);

                this.unpaidReportList_obj = this._unpaidReportList;

                if (this._unpaidReportList.length > 0) {
                  // set flags
                  this.showLoader = false;
                  this.showNoRecords = false;
                  this.showResult = true;
                } else {
                  // set flags in case of blank reponse or no result.
                  this.showLoader = false;
                  this.showNoRecords = true;
                  this.showResult = false;
                }
              }.bind(this)
            );
          });

        // ~ End  -----------------------------------------------------------------------------------------
      });
  }
  //  ~ End - ngOnInit_____________________________________________________________________________________

  // --  @details :  Class Functions for the Component ###################################################
  // Local Functions  ###########################################################################

  // --  @details :  receiveToggleSidebarObj (Emit Event)#######################################################
  //  ~ Start  -------------------------------------------------------------------------------------------------

  receiveToggleSidebarObj($event) {
    // Fetch the Customer Object Value from Event Emitter.
    this._opened = $event;

    // console.log("**** @@ Sidebar Open Object @@ ****");
    console.log(this._opened);
  }
  //  ~ End  ----------------------------------------------------------------------------------------------------

  // ~ Start ---------------------------------------------------------------
  // -- @details : Function get AreaList for autocomplete.
  getAreaList() {
    this.filteredAreas = this.area_name.valueChanges.pipe(
      startWith(""),
      map(
        areaValue =>
          areaValue ? this.filterAreas(areaValue) : this._areaList.slice()
      )
    );
  }

  filterAreas(areaValue: string) {
    return this._areaList.filter(
      area =>
        area.area_name.toLowerCase().indexOf(areaValue.toLowerCase()) === 0
    );
  }

  // ~ End ----------------------------------------------------------------

  // ~ Start ---------------------------------------------------------------
  // -- @details : Function get UsersList for autocomplete.
  getUsersList() {
    this.filteredUsers = this.user_name.valueChanges.pipe(
      startWith(""),
      map(
        userValue =>
          userValue ? this.filterUsers(userValue) : this._userList.slice()
      )
    );
  }

  filterUsers(userValue: string) {
    return this._userList.filter(
      user =>
        user.user_name.toLowerCase().indexOf(userValue.toLowerCase()) === 0
    );
  }

  // ~ End ----------------------------------------------------------------

  // ~ Start ---------------------------------------------------------------
  clearAgentNameField() {
    this.reportFilter.controls["user_name"].setValue("");
    this.user_id = "";
  }

  clearAreaNameField() {
    this.reportFilter.controls["area_name"].setValue("");
    this.area_id = "";
  }
  // ~ End ---------------------------------------------------------------
}

// -------------------  Component & Class Definition - End ---------------------------------------------
