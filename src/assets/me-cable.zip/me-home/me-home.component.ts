/*
____________________________________________________________________________________________________________
## COMPONENT FOR HOME PAGE ##
------------------------------------------------------------------------------------------------------------
|   VERSION     |   1.0      |   CREATED_ON  |   24-JAN-2018 |   CREATED_BY  |   AKASH
------------------------------------------------------------------------------------------------------------
## SERVICE FUNTIONALITY DETAILS 	##
------------------------------------------------------------------------------------------------------------
|   ++ Component Definition for Home Page
|   ++ Subscribe and Retrieve User Profile Details from MeUserProfileService
|   
------------------------------------------------------------------------------------------------------------
## CHANGE LOG DETAILS 				##
------------------------------------------------------------------------------------------------------------
|   ++ 24-JAN-2018    v1.0     - Created the New Component.
|   ++
____________________________________________________________________________________________________________

*/
// -- @details : Built and Custom Imports  ##################################################################
//  ~ Start  ------------------------------------------------------------------------------------------------
// Import Core Libraries/Functionalities

import { Component, OnInit } from "@angular/core";
import { PersistenceService } from "angular-persistence";
import { NgProgressModule, NgProgress } from "@ngx-progressbar/core";
import { RouterModule } from "@angular/router";
import { NgProgressRouterModule } from "@ngx-progressbar/router";
import {NgxChartsModule} from '@swimlane/ngx-charts';
import { ChartsModule } from 'ng2-charts';
import { Router } from "@angular/router";


// Import Custom Libraries/Functionalities/Services
import { MeCallHttpGetService         } from "../../../Service/me-call-http-get.service";
import { MeUserProfileService         } from "../../../Service/me-user-profile.service";
import { StorageType                  } from "../../../Service/Interfaces/storage-type.enum";
import { MeComplaintInterface         } from "../../../Service/Interfaces/me-complaint-interface";
import { SELECT_ITEM_HEIGHT_EM } from "@angular/material";
import { MeGzipService } from '../../../Service/me-gzip.service';


// Declare Generic Variables
declare var jQuery: any;
declare var $: any;
declare var M: any;

//  ~ End  ---------------------------------------------------------------------------------------------------

// -------------------  Component & Class Definition - Start --------------------------------------------------
@Component({
  selector: "app-me-home",
  templateUrl: "./me-home.component.html",
  styleUrls: ["./me-home.component.css"]
})
export class MeHomeComponent implements OnInit {

  // -- @details : Class variable declaration ###################################################################
  //  ~ Start  --------------------------------------------------------------------------------------------------

  private _userProfileData    : any;
  private _userLogin: any;
  private getRequestInput     : any = "";
  private getRequestInputObj  : any = {
    "user_id"                   : null,
    "owner_id"                  : null
  };
  private getRequestOwnerObj : any = 
  { "records": [
      { "owner_id" : null }
  ] } ;

  private collectionSummaryObj: any;
  private complaintSummaryObj : any;
  _opened: boolean = false;

// public class variables

ownerCompanyName         : String = "";
showLoader               : boolean = true;
showNoRecords            : boolean = false;

toggleSearchFlag         : boolean = false;
_collectionList          : any     = [];
_complaintList           : any     = [];
_areawiseCollectionList  : any     = [];
_userwiseCollectionList  : any     = [];
sortedData               : any     = [];

cableName                : any;
collectedAmountDisplay   : any;
pendingAmountDisplay     : any;
collectionTargetDisplay  : any;

completedCollCountDisplay: any;
pendingCollCountDisplay  : any;
totalCollCountDisplay    : any;


registeredComplDisplay   : any;
assignedComplDisplay     : any;
inprogressComplDisplay   : any;
cancelledComplDisplay    : any;
closedComplDisplay       : any;
totalComplDisplay        : any;

showCircularLoader1      : boolean = false;
showCircularLoader2      : boolean = false;
showCircularLoader3      : boolean = false;

customerWidgetObject  : any;
connectionWidgetObject: any;
expenseWidgetObject   : any;
collectionTrendObject : any;
areawiseCollectionObject : any;
userwiseCollectionObject : any;

// ----------------------------------------------------------------

displayNewCustomer   : number = 0;
displayTotalCustomer : number = 0;
displayCustomerPerct : number = 0;


displayActiveConnections      : number = 0;
displaySuspendedConnections   : number = 0;
displayDisconnetedConnections : number = 0;
displayTotalConnections       : number = 0;
displayConnectionPerct        : number = 0;

displayExpense      : number = 0;
displayTotalExpense : number = 0;
 
displayOpenComplaints    : number = 0;
displayTotalComplaints   : number = 0;
displayComplaintsPercent : number = 0;



// Chart Variables ----------------------------------------------------
// Collection Status Pie Chart01
showCircularLoader4      : boolean = false;
collectionStatusView   : any[]    = [450, 250];
collectionStatuscolorScheme = {
  domain: ['#a5d6a7', '#e57373']
};

collectionStatusData        = [
  {
    "name" : "Complete",
    "value": 0
  },
  {
    "name" : "Pending",
    "value": 0
  }
];

// Connection Status Pie Chart01
showCircularLoader6 = false;
connectionStatusView: any[]    = [500, 220];
connectionStatuscolorScheme = {
  domain: ['#a5d6a7', '#ffc107', '#e57373', '#03a9f4', '#5e35b1']
};

percentageFormatting: (value: number) => any = percentage => Math.round(percentage) ;

connectionStatusData = [
  {
    "name": "Active",
    "value": 0
  },
  {
    "name": "Suspended",
    "value": 0
  },
  {
    "name": "Disconnected",
    "value": 0
  }
];

// Complaints - Advanced Pie Grid
showCircularLoader7 : boolean                  = false;
complaintStatusView : any[]                    = [450, 300];
complaintStatuscolorScheme = {
  domain: ['#FAC152', '#42A5F5', '#5c6bc0', '#66BB6A', '#EF5350']
};
complaintStatusData = [
  {
    "name": "Registered",
    "value": 0
  },
  {
    "name": "Assigned",
    "value": 0
  },
  {
    "name": "Inprogress",
    "value": 0
  },
  {
    "name": "Closed",
    "value": 0
  },
  {
    "name": "Cancelled",
    "value": 0
  }
];


// bar chart options =======================================================
showCircularLoader5 : boolean                  = false;
  public barChartOptions:any = {
    scaleShowVerticalLines: false,
    responsive: true,
    
  };
  // public collectionTrendLabels:string[] = ['Mar-06', 'Mar-07', 'Mar-08', 'Mar-09', 'Mar-10','Mar-11','Mar-12'];
  public collectionTrendLabels:string[] = [];
  public barChartType:string = 'line';
  public barChartLegend:boolean = true;
   
 
  public collectionTrendData:any[] = [
    {data: [0, 0, 0, 0, 0, 0, 0], label: 'Amount'}
  ];

  public barChartColors:Array<any> = [
     
    { // dark grey
      backgroundColor: '#81d4fa',
      borderColor: '#03a9f4',
      pointBackgroundColor: 'rgba(77,83,96,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(77,83,96,1)'
    } 
  ];

  // Chart Variables ----------------------------------------------------

// Class variable declaration ~ End  --------------------------------------------------------------------- 

  

  // --  @details :  constructor #################################################################################
  //  ~ Start  ---------------------------------------------------------------------------------------------------
  constructor(
    public  callHttpGet               : MeCallHttpGetService,
    public  userProfileService        : MeUserProfileService,
    private homePersistenceService    : PersistenceService,
    public  router                    : Router,
    private gzipService       :MeGzipService,
  ) {

 // Intialize Value
 this.collectedAmountDisplay    = 0;
 this.pendingAmountDisplay      = 0;
 this.collectionTargetDisplay   = 0;

 //
 this.completedCollCountDisplay = 0;
 this.pendingCollCountDisplay   = 0;
 this.totalCollCountDisplay     = 0;

 this.registeredComplDisplay    = 0;
 this.assignedComplDisplay      = 0;
 this.inprogressComplDisplay    = 0;
 this.cancelledComplDisplay     = 0;
 this.closedComplDisplay        = 0;
 this.totalComplDisplay         = 0;

 //
 this.showCircularLoader1 = true;
 this.showCircularLoader2 = true;
 this.showCircularLoader3 = true;
 this.showCircularLoader4 = true;
 this.showCircularLoader5 = true;
 this.showCircularLoader6 = true;
 this.showCircularLoader7= true;

 // initialize display variables
 this.displayNewCustomer            = 0;
 this.displayTotalCustomer          = 0;
 this.displayActiveConnections      = 0;
 this.displaySuspendedConnections   = 0;
 this.displayDisconnetedConnections = 0;
 this.displayTotalConnections       = 0;
 this.displayExpense                = 0;
 this.displayTotalExpense           = 0;

  }

  //  ~ End  ---------------------------------------------------------------------------------------------------

  // --  @details :  ngOnInit ##################################################################################
  //  ~ Start  -------------------------------------------------------------------------------------------------
  ngOnInit() {
    // Intialize Loader Flags
    this.showCircularLoader1 = true;
    this.showCircularLoader2 = true;
    this.showCircularLoader3 = true;
    this.showCircularLoader4 = true;
    this.showCircularLoader5 = true;
    this.showCircularLoader6 = true;
    this.showCircularLoader7= true;

     // initialize display variables
     this.displayNewCustomer       = 0;
     this.displayTotalCustomer     = 0;
     this.displayActiveConnections = 0;
     this.displayTotalConnections  = 0;
     this.displayExpense           = 0;
     this.displayTotalExpense      = 0;


    console.log(
      "%c  Inside home component ngonInit : ",
      "background: #1898dd;color: white; font-weight: bold;"
    );

    // Fetch the User Login Details Stored in the Cache
    this._userLogin = this.homePersistenceService.get("userLogin",StorageType.SESSION);
    console.log("User Login", this._userLogin);

    // make call to User Profile Request based on login details
    this.userProfileService.makeRequest_UserProfile(this._userLogin).subscribe(response => {
       
      // this.gzipService.makeRequest_uncompress(response).then(function(result) {
        
        // console.log("Profile Inside Home Component :", result);
        this._userProfileData = response;

      
      if(this._userProfileData.userDetails.user_role_id != "1002" && this._userProfileData.userDetails.user_role_id != "1003"){
        this.router.navigateByUrl('/accessdenied');
      }

      console.warn(
        "----------------- User Profile Response ----------------- "
      );
      console.log(this._userProfileData);
      console.log(this._userProfileData.ownerDetails); 

      // assigng to display in header nav bar
      this.ownerCompanyName = response.ownerDetails.owner_company_name;

        
      // assign values
      this.getRequestInputObj.user_id  = this._userProfileData.userDetails.user_id ;
      this.getRequestInputObj.owner_id = this._userProfileData.ownerDetails.owner_id;

      // get the Input JSON format for making http request.
      this.getRequestInput = this.callHttpGet.createGetRequestRecord(
        this.getRequestInputObj
      );
      console.log(
        "%c  Request Input : >>> ",
        "color: green; font-weight: bold;",
        this.getRequestInput
      );    
      

      // make call for retrieving Collection Status
      // Collection Status ~ Start  -------------------------------------------------------------------------------------------------
        this.callHttpGet.makeRequest_GetCollectionList(this.getRequestInput).subscribe(response => {
          // Log Response - Remove Later
          console.warn(
            "%c ___________________________ Collection List Response ___________________________",
            "background: #4dd0e1;color: black; font-weight: bold;"
          );
          // console.log(response);
          // console.log(response.collectionList.length);

          this.gzipService.makeRequest_uncompress(response).then(function(result) {
              
            this._collectionList = result.collectionList;

            if(this._collectionList.length > 0 ) {

              // assign to local variable
              // this._collectionList = response.collectionList;

              // set the reponse to datastore 
              // this.collectionDataStoreService.setCollectionStore(this._collectionList);

              // assign to loop variable
              this.sortedData = this._collectionList.slice();

              this.collectionSummaryObj =  this.calculateCollectionSummary(this.sortedData);

              console.log(  "%c ___________________________ Collection Summary Object ___________________________ ",
              "background: #6a1b9a ;color: white; font-weight: bold;",    );
              console.log(this.collectionSummaryObj);
  
              //__________________________ Assign Values ~ Start ________________________________________
                           
              this.collectionStatusData = [
                { "name": "Complete",
                  "value": this.collectionSummaryObj.collectedAmount},
                { "name": "Pending",
                  "value": this.collectionSummaryObj.pendingAmount}
              ]           
              ;
            
              //__________________________ Assign Values ~ End ________________________________________

              //set loader false
              this.showCircularLoader4 = false;

            }
            else {
              this.showCircularLoader4 = false;
              
              this.collectionStatusData = [
                { "name": "Complete",
                  "value": 0
                },
                { "name": "Pending",
                  "value": 0
                }
              ]           
              ;


            }
            

          }.bind(this))

        });

       // Collection Status ~ End  -------------------------------------------------------------------------------------------------   


        // make call for retrieving Complaint Status
        // Complaint Status ~ Start  -------------------------------------------------------------------------------------------------

        // make call for retrieving Complaint List
        //  ~ Start  -------------------------------------------------------------------------------------------------
        this.callHttpGet.makeRequest_ManageComplaint(this.getRequestInput).subscribe(response => {
            // // Log Response - Remove Later
            // console.warn(
            //   "%c ___________________________ Manage Complaint Response ___________________________",
            //   "background: #4dd0e1;color: black; font-weight: bold;"
            // );

            // console.log(response.complaintsList);
            // console.log("Complaint Length : ", response.complaintsList.length);

            this.gzipService.makeRequest_uncompress(response).then(function(result) {
              
             // assign response to local variable
             this._complaintList = result.complaintsList;
  
              if(this._complaintList.length > 0 ) {

                // Calculate and assign summary to local variable
                this.complaintSummaryObj = this.calculateComplaintSummary(this._complaintList);
                  
                //__________________________ Assign Values ~ Start ________________________________________
                // Append Zeroes for displaying Counts if the value of count is less than 10
                this.complaintStatusData = [
                  {
                    "name": "Registered",
                    "value": this.complaintSummaryObj.registeredCount
                  },
                  {
                    "name": "Assigned",
                    "value": this.complaintSummaryObj.assignedCount
                  },
                  {
                    "name": "Inprogress",
                    "value": this.complaintSummaryObj.inprogressCount
                  },
                  {
                    "name": "Closed",
                    "value": this.complaintSummaryObj.closedCount
                  },
                  {
                    "name": "Cancelled",
                    "value": this.complaintSummaryObj.cancelledCount
                  }
                ];
  
                //__________________________ Assign Values ~ End ________________________________________

                this.displayOpenComplaints = this.complaintSummaryObj.registeredCount + this.complaintSummaryObj.assignedCount + this.complaintSummaryObj.inprogressCount;
                this.displayTotalComplaints = this.complaintSummaryObj.registeredCount + this.complaintSummaryObj.assignedCount 
                                          + this.complaintSummaryObj.inprogressCount + this.complaintSummaryObj.closedCount
                                          + this.complaintSummaryObj.cancelledCount;
                this.displayComplaintsPercent = this.caculatePercentage(this.displayOpenComplaints,this.displayTotalComplaints );

                // hide loader   
                this.showCircularLoader7 = false;
              }
              else {
  
                this.displayOpenComplaints    = 0;
                this.displayTotalComplaints   = 0;
                this.displayComplaintsPercent = 0;


                this.showCircularLoader7 = false;
                this.showNoRecords = true;
                
              }
            }.bind(this))

          });  




        // Complaint Status ~ End  -------------------------------------------------------------------------------------------------

         
        // assign owner id
        this.getRequestOwnerObj.records[0].owner_id = this._userProfileData.ownerDetails.owner_id;
        console.log("----------- getRequestOwnerObj -----------");
        console.log(this.getRequestOwnerObj );
  

        // make call for retrieving Complaint List
        // makeRequest_GetCustomerCount ~ Start  ------------------------------------------------------------------------------
        this.callHttpGet.makeRequest_GetCustomerCount(this.getRequestOwnerObj).subscribe(response => {

            // Log Response - Remove Later
            console.warn(
              "%c ___________________________ makeRequest_GetCustomerCount Response ___________________________",
              "background: #4dd0e1;color: black; font-weight: bold;"
            );

            console.log(response);
            // assign response
            this.customerWidgetObject = response;


            this.displayNewCustomer   = this.customerWidgetObject.newCustomersCount;
            this.displayTotalCustomer = this.customerWidgetObject.totalCustomersCount;  
            this.displayCustomerPerct =  this.caculatePercentage(this.displayNewCustomer,this.displayTotalCustomer);

            console.log("-- Percentage --");
            console.log(this.displayCustomerPerct);

            this.showCircularLoader1 = false;

          });
          // makeRequest_GetCustomerCount ~ End  ------------------------------------------------------------------------------


          // make call for retrieving Connection Status
          // makeRequest_GetConnectionStatus ~ Start  ------------------------------------------------------------------------------
        
          this.callHttpGet.makeRequest_GetConnectionStatus(this.getRequestOwnerObj).subscribe(response => {

            // Log Response - Remove Later
            console.warn(
              "%c ___________________________ makeRequest_GetConnectionStatus Response ___________________________",
              "background: #4dd0e1;color: black; font-weight: bold;"
            );

            
            // assign response
            this.connectionWidgetObject = response;
            console.log(this.connectionWidgetObject);


            // this.displayNewCustomer   = this.customerWidgetObject.newCustomersCount;
            // this.displayTotalCustomer = this.customerWidgetObject.totalCustomersCount;  
            if(this.connectionWidgetObject.connectionStatus.length > 0) {

              // assign values to connection status pie
              this.connectionStatusData =  this.connectionWidgetObject.connectionStatus;
              this.showCircularLoader6 = false;


              // Calculate Connection Widget Summary
              let totalConnection = 0;
              let activeConnection = 0;

              this.connectionWidgetObject.connectionStatus.forEach(function(item,index){

                  if(item.name === 'ACTIVE') {
                    activeConnection = item.value;
                  }

                  // sum total connections
                  totalConnection  += item.value;

              });

              // assign to widget display variables
              this.displayActiveConnections = activeConnection;
              this.displayTotalConnections  = totalConnection;
              this.displayConnectionPerct  = this.caculatePercentage(this.displayActiveConnections,this.displayTotalConnections);
              
            }
            else{
              this.displayActiveConnections = 0;
              this.displayTotalConnections  = 0;
              this.displayConnectionPerct  = 0;
              this.showCircularLoader6 = false;
            }
            

            

          });

           // makeRequest_GetConnectionStatus ~ End  ------------------------------------------------------------------------------


           // make call for retrieving Collection Trend
          // makeRequest_GetCollectionTrend ~ Start  ------------------------------------------------------------------------------


          this.callHttpGet.makeRequest_GetCollectionTrend(this.getRequestOwnerObj).subscribe(response => {

            // Log Response - Remove Later
            console.warn(
              "%c ___________________________ makeRequest_GetCollectionTrend Response ___________________________",
              "background: #1dd0e1;color: black; font-weight: bold;"
            );

            
            // assign response
            this.collectionTrendObject = response;
            console.log(this.collectionTrendObject);

            if( this.collectionTrendObject.collectionTrend.length > 0) {

              this.collectionTrendObject.collectionTrend =  this.collectionTrendObject.collectionTrend.reverse();

              // Extract Days
              var arry_idx = 0;
              var collectionLables = [];
              var collectionData = [];

              this.collectionTrendObject.collectionTrend.forEach(function(item,index){
                console.log("------- Data -------");
                console.log(item.DAY);
                console.log(item.amount);

                // extract and assignn values
                collectionLables[arry_idx]  = item.DAY;
                collectionData[arry_idx]  = item.amount;

                arry_idx =  arry_idx + 1;

              });

              // Assign values to Bar Chart Variables.
              this.collectionTrendLabels = collectionLables;
              this.collectionTrendData[0].data = collectionData;
    
              console.log("------- Bar Chart Data Output -------");
              console.log( collectionLables);
              console.log( collectionData);

              this.showCircularLoader5 = false;

            }
            else {
              this.showCircularLoader5 = false;
            }

          });

          // makeRequest_GetCollectionTrend ~ End  ------------------------------------------------------------------------------


          // makeRequest_getAreawiseCollection ~ Start  ------------------------------------------------------------------------------
          this.callHttpGet.makeRequest_getAreawiseCollection(this.getRequestOwnerObj).subscribe(response => {

            this.areawiseCollectionObject = response;
           

            console.log("Areawise Collection");
            console.log(this.areawiseCollectionObject);

            if(this.areawiseCollectionObject.areawiseCollections.length > 0 ) {

              // assign the collection array
              this._areawiseCollectionList = this.areawiseCollectionObject.areawiseCollections;


            }
            else {
              console.log("--- No Areawise Data ---");
            }

          });

          // makeRequest_getAreawiseCollection ~ End  ------------------------------------------------------------------------------
          // makeRequest_getAgentiseCollection ~ Start  ------------------------------------------------------------------------------
          this.callHttpGet.makeRequest_getUseriseCollection(this.getRequestOwnerObj).subscribe(response => {

            this.userwiseCollectionObject = response;
           

            console.log("Userwise Collection");
            console.log(this.userwiseCollectionObject);

            if(this.userwiseCollectionObject.userwiseCollections.length > 0 ) {

              // assign the collection array
              this._userwiseCollectionList = this.userwiseCollectionObject.userwiseCollections;


            }
            else {
              console.log("--- No userwise Data ---");
            }

          });

          // makeRequest_getAgentiseCollection ~ End  ------------------------------------------------------------------------------
          




      // }.bind(this))
    });
   
  }
  //ngOnInit  ~ End  ----------------------------------------------------------------------------------------------------


  // -- @details : Local Functions______________________________________________________________________  
  // --  @details :  receiveToggleSidebarObj (Emit Event)#######################################################
  //  ~ Start  -------------------------------------------------------------------------------------------------

  receiveToggleSidebarObj($event) {
    // Fetch the Customer Object Value from Event Emitter.
    this._opened = $event;

    // console.log("**** @@ Sidebar Open Object @@ ****");
    // console.log(this._opened);

  }
  //  ~ End  ----------------------------------------------------------------------------------------------------


  // -- @details : Calculate Collection Summary for Dashboard  #########################################
  //  ~ Calculate  Collection Summary ~ Start  --------------------------------------------------------- 
    calculateCollectionSummary(p_in_array): any {
  
        var  collectionSummary = 
        {
          collectedAmount     : 0.0,
          pendingAmount       : 0.0,
          collectionTarget    : 0,
          collectionsCompleted: 0,
          collectionsPending  : 0,
          totalcollections    : 0,
          FullyPaidCount      : 0,
          FullPaidSum         : 0.0,
          PartialPaidCount    : 0,
          PartialPaidSum      : 0.0,
          PartialUnPaidSum    : 0.0,
          UnPaidCount         : 0,
          UnPaidSum           : 0.0,
          percentageComplete  :0,
          percentagePending   :0,
          percentageStats     : []

  
        }
  
        console.log(  "%c _________________Calculate Collection Summary Array Input ___________________________ ",
        "background: #4dd0e1;color: black; font-weight: bold;",    );
        console.log(p_in_array);
        
  
        // Loop through array for calculation ~ Start
        p_in_array.forEach(function (balanceObj, index) {

        // caculate collection target
        collectionSummary.collectionTarget =  collectionSummary.collectionTarget +  parseFloat (balanceObj.collection_amount_original); 
  
        if(balanceObj.bill_type === 'FP') {
              collectionSummary.FullPaidSum     = collectionSummary.FullPaidSum + parseFloat (balanceObj.collection_amount_original);
              collectionSummary.FullyPaidCount += 1 ;
          }
          else if(balanceObj.bill_type === 'PP') {
            collectionSummary.PartialPaidSum = collectionSummary.PartialPaidSum + parseFloat (balanceObj.received_amount);
            collectionSummary.PartialUnPaidSum    = collectionSummary.PartialUnPaidSum + parseFloat (balanceObj.collection_amount);
            collectionSummary.PartialPaidCount += 1 ;
          }
          else if(balanceObj.bill_type === 'UP') {
            collectionSummary.UnPaidSum    = collectionSummary.UnPaidSum + parseFloat (balanceObj.collection_amount);
            collectionSummary.UnPaidCount += 1 ;
          }
          else if(balanceObj.bill_type === 'AB') {
            collectionSummary.FullPaidSum     = collectionSummary.FullPaidSum + parseFloat (balanceObj.collection_amount_original);
            collectionSummary.FullyPaidCount += 1 ;
          }
  
        
        }); // Loop through array for calculation ~ End
  
  
        // Caculate Summary
        collectionSummary.collectedAmount  = collectionSummary.FullPaidSum + collectionSummary.PartialPaidSum;
        collectionSummary.pendingAmount    = collectionSummary.PartialUnPaidSum + collectionSummary.UnPaidSum;
  
        // Calculate Counts
        collectionSummary.collectionsCompleted = collectionSummary.FullyPaidCount;
        collectionSummary.collectionsPending   = collectionSummary.PartialPaidCount + collectionSummary.UnPaidCount;
        collectionSummary.totalcollections     = collectionSummary.FullyPaidCount + collectionSummary.PartialPaidCount + collectionSummary.UnPaidCount;
  
        collectionSummary.percentageComplete = ((collectionSummary.collectionsCompleted/collectionSummary.totalcollections  ) *100);
        collectionSummary.percentageComplete = Math.round(collectionSummary.percentageComplete);
        collectionSummary.percentagePending = ((collectionSummary.collectionsPending/collectionSummary.totalcollections  ) *100);
        collectionSummary.percentagePending = Math.round(collectionSummary.percentagePending);
        
  
        console.log("---------- Percentage Calculation -------------");
        console.log("Complete : >>>> ",collectionSummary.percentageComplete);
        console.log("Pending : >>>> ",collectionSummary.percentagePending);
      
        // assign percentage calculation to array for assigning to doughnut chart
        collectionSummary.percentageStats[0] = collectionSummary.percentagePending;
        collectionSummary.percentageStats[1] = collectionSummary.percentageComplete;
  
  
        console.log(  "%c ___________________________ Collection Summary  ___________________________ ",
        "background: #4dd0e1;color: black; font-weight: bold;",    );
        console.log(collectionSummary);
      
        // Assign value to Collection Summary Object for displaying values
        return collectionSummary;
  
  
      }
      //  ~ Calculate Collection Summary ~ End  --------------------------------------------------------------------- 
  
      // -- @details : Calculate Complaint Summary for Dashboard  ####################################################
      //  ~ Calculate Complaint Summary ~ Start  --------------------------------------------------------------------- 
      calculateComplaintSummary(p_in_array): any {
  
      var  complaintSummary = 
        {
              registeredCount: 0,
              assignedCount  : 0,
              inprogressCount: 0,
              cancelledCount : 0,
              closedCount    : 0,
              totalCount     : 0
        }
  
        console.log(  "%c _______________ Calculate Complaint Summary Array Input ___________________________ ",
        "background: #ab47bc ;color: black; font-weight: bold;",    );
        console.log(p_in_array);
  
  
        // Loop through array for calculation ~ Start
        p_in_array.forEach(function (complntObj, index) {
          
          console.log(complntObj);
  
          if(complntObj.complaint_status === "" ) {
  
          }
          
          switch(complntObj.complaint_status) { 
            case "REGISTERED": { 
              complaintSummary.registeredCount += 1; 
                break; 
            } 
            case "ASSIGNED": { 
              complaintSummary.assignedCount += 1; 
                break; 
            } 
            case "IN-PROGRESS": {
              complaintSummary.inprogressCount += 1; 
                break;    
            } 
            case "CANCELLED": { 
              complaintSummary.cancelledCount += 1; 
                break; 
            }  
            case "CLOSED": { 
              complaintSummary.closedCount += 1; 
                break; 
            }  
            default: { 
                console.log("Invalid choice"); 
                break;              
            } 
          }
            
          
        }); // Loop through array for calculation ~ End
  
        // Calculate Total
        complaintSummary.totalCount =  complaintSummary.registeredCount +  complaintSummary.assignedCount +  complaintSummary.inprogressCount +
        complaintSummary.cancelledCount + complaintSummary.closedCount ;
  
  
        console.log(  "%c _______________ Calculate Complaint Summary Object ___________________________ ",
        "background: #ab47bc ;color: black; font-weight: bold;",    );
        console.log(complaintSummary);
  
        //return Complaint Summary
        return complaintSummary;
  
      }
      //  ~ Calculate Complaint Summary ~ End  ---------------------------------------------------------------------
  
      // private _toggleSidebar() {
      //   this._opened = !this._opened;
      // }
  

      caculatePercentage(param1,param2){
       
        let num1 : number = param1;
        let num2 : number = param2;
        let percentage : number = 0;

        if( num2 <= 0 ) {
          percentage = 0;
        }
        else {
          //calculate percentage
          percentage =  ((num1/num2)*100);
          console.log(  "%c _______________ Percentage Value ___________________________ ",
          "background: #1b47bc ;color: white; font-weight: bold;",    );
          console.log(percentage);
          percentage = Math.round(percentage);

        }

        return percentage;

      }

}

// -------------------  Component & Class Definition - End --------------------------------------------------