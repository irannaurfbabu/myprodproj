import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-me-forms-links',
  templateUrl: './me-forms-links.component.html',
  styleUrls: ['./me-forms-links.component.css']
})
export class MeFormsLinksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
