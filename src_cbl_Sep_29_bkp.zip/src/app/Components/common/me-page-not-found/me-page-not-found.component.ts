import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-me-page-not-found',
  templateUrl: './me-page-not-found.component.html',
  styleUrls: ['./me-page-not-found.component.css']
})
export class MePageNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
