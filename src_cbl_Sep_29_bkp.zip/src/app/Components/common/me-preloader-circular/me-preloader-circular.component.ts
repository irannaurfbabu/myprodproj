import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-me-preloader-circular',
  templateUrl: './me-preloader-circular.component.html',
  styleUrls: ['./me-preloader-circular.component.css']
})
export class MePreloaderCircularComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
