import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-me-footer',
  templateUrl: './me-footer.component.html',
  styleUrls: ['./me-footer.component.css']
})
export class MeFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
