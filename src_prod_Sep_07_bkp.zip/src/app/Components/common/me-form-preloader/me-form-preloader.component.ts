import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-me-form-preloader',
  templateUrl: './me-form-preloader.component.html',
  styleUrls: ['./me-form-preloader.component.css']
})
export class MeFormPreloaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
