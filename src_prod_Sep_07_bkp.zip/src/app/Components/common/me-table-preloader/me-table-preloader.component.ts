import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-me-table-preloader',
  templateUrl: './me-table-preloader.component.html',
  styleUrls: ['./me-table-preloader.component.css']
})
export class MeTablePreloaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
