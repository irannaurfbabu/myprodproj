/*
____________________________________________________________________________________________________________
## COMPONENT OBJECT FOR BILL HISTORY ##
------------------------------------------------------------------------------------------------------------
|   VERSION     |   1.0      |   CREATED_ON  |   23-MAY-2018 |   CREATED_BY  |   AKASH
------------------------------------------------------------------------------------------------------------
## COMPONENT FUNTIONALITY DETAILS 	##
------------------------------------------------------------------------------------------------------------
|   ++ HTTP Service for Bill history details retrieval
|   
------------------------------------------------------------------------------------------------------------
## CHANGE LOG DETAILS 				##
------------------------------------------------------------------------------------------------------------
|   ++ 23-MAY-2018    v1.0     - Created the New Component.
|   ++
____________________________________________________________________________________________________________

*/

// -- @details : Built and Custom Imports  #################################################################
//  ~ Start  -----------------------------------------------------------------------------------------------
// Import Angular Core Libraries/Functionalities
import { Component, OnInit, Input } from '@angular/core';
import { MeCallHttpGetService } from '../../../Service/me-call-http-get.service';
import { PersistenceService } from 'angular-persistence';
import { ActivatedRoute } from '@angular/router';
import { IPageChangeEvent } from '@covalent/core/paging';
import { TdDataTableService, TdDataTableSortingOrder, ITdDataTableSortChangeEvent, ITdDataTableColumn } from '@covalent/core/data-table';

// Import Custom Libraries/Functionalities/Services
import { MeUserProfileService } from '../../../Service/me-user-profile.service';
import { StorageType } from "../../../Service/Interfaces/storage-type.enum";

// Decimal Format for integer values displayed in tera datatable.
const DECIMAL_FORMAT: (v: any) => any = (v: number) => v.toFixed(2);

//  ~ End  -------------------------------------------------------------------------------------------------


// -------------------  Component & Class Definition - Start -----------------------------------------------

@Component({
  selector: 'app-me-bill-history',
  templateUrl: './me-bill-history.component.html',
  styleUrls: ['./me-bill-history.component.css']
})
export class MeBillHistoryComponent implements OnInit {

  // -- @details : Class variable declaration ###################################################################
  //  ~ Start - variable declaration _____________________________________________________________________________

  // Class Local variables
 // All variables used within the class must be private

 @Input() setCustNumObj: any;
 private _customerDetails_obj   : any;
 private getRequestInput        : any = "";
 private _userLogin             : any;
 private _userProfileData       : any;
 private postRequestCustomerObject: any =
 {
   records: [{

       owner_id: null,
       customer_number: null,
      
    
   }]
 };

 // Local Variables
 showNoRecords         :boolean=true;
 showLoader   : boolean = true;

 _BillHistory  :any=[];
 customer_number_param : any     = "";

 //Url Variabes
  public id:any;
  public source:string;

 // Tera DataTable Local Fields
 filteredData: any[] = [];
 filteredTotal: number = 0;
 searchTerm: string = '';
 fromRow: number = 1;
 currentPage: number = 1;
 pageSize: number = 50;
 sortBy: string = 'bill_id';
 selectedRows: any[] = [];
 sortOrder: TdDataTableSortingOrder = TdDataTableSortingOrder.Ascending;
 

// Tera DataTable Set Column name/Label and other features.
columns: ITdDataTableColumn[] = [
 { name: 'bill_id', label: 'Bill ID', filter: true, sortable: true, width: 120 },
 { name: 'bill_period_start', label: 'Bill Month', filter: false, sortable: true, width: 100 },
 { name: 'bill_date', label: 'Bill Date',  filter: true, width: 250 },
 { name: 'bill_type', label: 'Bill Type', filter: true, sortable: true, width: 120 },
 { name: 'previous_due', label: 'Previous Due', sortable: true, filter: true, width: 120, numeric: true, format: DECIMAL_FORMAT },
 { name: 'rent_amount', label: 'Rent Amount', filter: true, sortable: true, width: 120 , numeric: true, format: DECIMAL_FORMAT},
 { name: 'tax_total', label: 'Tax Total', sortable: true, filter: true, width: 130, numeric: true, format: DECIMAL_FORMAT },
 { name: 'bill_amount', label: 'Bill Amount', sortable: true, filter: true, width: 130 , numeric: true, format: DECIMAL_FORMAT},
 { name: 'collection_amount_original', label: 'Original Coll Amount', filter: true, sortable: true, width: 200, numeric: true, format: DECIMAL_FORMAT },
 { name: 'collection_amount', label: 'Collection Amount', sortable: true, filter: true,  width: 190, numeric: true, format: DECIMAL_FORMAT},
 { name: 'rebate_amount', label: 'Rebate Amount', sortable: true, filter: true,  width: 180, numeric: true, format: DECIMAL_FORMAT},
 { name: 'received_amount', label: 'Received Amount', sortable: true, filter: true,  width: 180, numeric: true, format: DECIMAL_FORMAT },
 { name: 'outstanding_balance', label: 'Outstanding Bal', filter: true, sortable: true, width: 150, numeric: true, format: DECIMAL_FORMAT },
 { name: 'opening_balance', label: 'Opening Bal', sortable: true, filter: true, width: 150, numeric: true, format: DECIMAL_FORMAT},
 { name: 'closing_balance', label: 'Closing Bal', sortable: true, filter: true,  width: 150 , numeric: true, format: DECIMAL_FORMAT},
 { name: 'received_date', label: 'Received Date', sortable: true, filter: true,  width: 250 },
 ]; 
//  ~ End  - variable declaration _______________________________________________________________________________

// --  @details :  constructor #############################################################################
//  ~ Start -constructor ------------------------------------------------------------------------------------
 constructor(
   public  callHttpGet                      : MeCallHttpGetService,
   private customerDetailsPersistenceService: PersistenceService,
   public  userProfileService               : MeUserProfileService,
   public  route                            : ActivatedRoute,
   private _dataTableService: TdDataTableService


 ) { 
   this.customer_number_param = +this.route.snapshot.params["id"];
 }
//  ~ End -constructor  --------------------------------------------------------------------------------------


  // --  @details :  ngOnChanges ##################################################################################
  //  ~ Start -ngOnChanges  ---------------------------------------------------------------------------------------
  // ngOnChanges get updated customerNumber
  
    ngOnChanges(setCustNumObj:any) {
      // console.log('on change',this.setCustNumObj);
      this.customer_number_param = this.setCustNumObj;
      this.filteredData = [];
      this.filteredTotal = 0;
      this.ngOnInit();
    }
  
  //  ~ End -ngOnChanges  ---------------------------------------------------------------------------------------



 // --  @details :  ngOnInit ##################################################################################
 //  ~ Start -ngOnInit  ---------------------------------------------------------------------------------------
 ngOnInit() {

     // Fetch the User Login Details Stored in the Cache
     this._userLogin = this.customerDetailsPersistenceService.get(
       "userLogin",
       StorageType.SESSION
     );
     console.warn("----------------- User Login ----------------- ");
     console.dir(this._userLogin);
  // make call to get user profile details
//  ~ Start  -------------------------------------------------------------------------------------------------
this.userProfileService
.makeRequest_UserProfile(this._userLogin)
.subscribe(response => {
  this._userProfileData = response;

  console.warn(
    "----------------- User Profile Response payment ----------------- "
  );
  console.log(this._userProfileData);
  console.log(this._userProfileData.ownerDetails);

});
// ~ End  -------------------------------------------------------------------------------------------------


  if(this.setCustNumObj) {

    this.customer_number_param = this.setCustNumObj;
    console.log('this.customer_number_param',this.customer_number_param);

  }
  else 
  {
    this.route.queryParams.subscribe(params => {
      this.id = params["id"];
      this.source = params["Source"];
      });
      
      
      this.customer_number_param = +this.id;
    // this.postRequestCustomerObject.records[0].customer_number =this.customer_number_param;
    console.log('postRequestCustomerObject payment',this.postRequestCustomerObject);      

  }


// initialize 
this.postRequestCustomerObject.records[0].owner_id = this._userProfileData.ownerDetails.owner_id;
this.postRequestCustomerObject.records[0].customer_number =this.customer_number_param;
console.log('postRequestCustomerObject payment',this.postRequestCustomerObject);




// Subscribing to get GetCustomerPayments
this.callHttpGet.makeRequest_GetBillHistory(this.postRequestCustomerObject).subscribe(response => {
 console.log(
   "%c Subscription List ***** ----------------------------------------------------------- ",
   "background: #ff5722;font-weight: bold;color: white; "
 );

 this._BillHistory = response.billHistory;
 this.filteredData=this._BillHistory;
 this.filteredTotal = this._BillHistory.length;
 this.filter();
 if(this._BillHistory.length !=0){
   this.showNoRecords=false;
   this.showLoader = false;
   }
 console.log('makeRequest_GetCustomerPayments payment',this._BillHistory);
});
// makeRequest_GetCustomerPayments() ~ End  ----------------------------------------------------------------------------------------

 
 }

  //  ~ End -ngOnInit  -------------------------------------------------------------------------------------
 
  // --  @details :  Class Functions for the Component #######################################################
 //  ~ Start  -------------------------------------------------------------------------------------------------

 sort(sortEvent: ITdDataTableSortChangeEvent): void {
   this.sortBy = sortEvent.name;
   this.sortOrder = sortEvent.order;
   this.filter();
 }

 search(searchTerm: string): void {
   this.searchTerm = searchTerm;
   this.filter();
 }

 page(pagingEvent: IPageChangeEvent): void {
   this.fromRow = pagingEvent.fromRow;
   this.currentPage = pagingEvent.page;
   this.pageSize = pagingEvent.pageSize;
   this.filter();
 }

 filter(): void { 
   let newData: any[] = this._BillHistory;
   let excludedColumns: string[] = this.columns
   .filter((column: ITdDataTableColumn) => {
     return ((column.filter === undefined && column.hidden === true) ||
             (column.filter !== undefined && column.filter === false));
   }).map((column: ITdDataTableColumn) => {
     return column.name;
   });
   newData = this._dataTableService.filterData(newData, this.searchTerm, true, excludedColumns);
   this.filteredTotal = newData.length;
   newData = this._dataTableService.sortData(newData, this.sortBy, this.sortOrder);
   newData = this._dataTableService.pageData(newData, this.fromRow, this.currentPage * this.pageSize);
   this.filteredData = newData;
 }

 // ~ End -----------------------------------------------------------------------------------------

}
// -------------------  Component & Class Definition - Start ---------------------------------------------
