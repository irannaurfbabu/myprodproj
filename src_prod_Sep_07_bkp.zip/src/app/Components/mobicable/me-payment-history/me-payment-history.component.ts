/*
____________________________________________________________________________________________________________
## COMPONENT OBJECT FOR PAYMENT HISTORY ##
------------------------------------------------------------------------------------------------------------
|   VERSION     |   1.0      |   CREATED_ON  |   23-MAY-2018 |   CREATED_BY  |   AKASH
------------------------------------------------------------------------------------------------------------
## COMPONENT FUNTIONALITY DETAILS 	##
------------------------------------------------------------------------------------------------------------
|   ++ HTTP Service for Payment history details retrieval
|   
------------------------------------------------------------------------------------------------------------
## CHANGE LOG DETAILS 				##
------------------------------------------------------------------------------------------------------------
|   ++ 23-MAY-2018    v1.0     - Created the New Component.
|   ++
____________________________________________________________________________________________________________

*/

// -- @details : Built and Custom Imports  #################################################################
//  ~ Start  -----------------------------------------------------------------------------------------------
// Import Angular Core Libraries/Functionalities
import { Component, OnInit, Input } from '@angular/core';
import { MeCallHttpGetService } from '../../../Service/me-call-http-get.service';
import { PersistenceService } from 'angular-persistence';
import { ActivatedRoute } from '@angular/router';
import { IPageChangeEvent } from '@covalent/core/paging';
import { TdDataTableService, TdDataTableSortingOrder, ITdDataTableSortChangeEvent, ITdDataTableColumn } from '@covalent/core/data-table';

// Import Custom Libraries/Functionalities/Services
import { MeUserProfileService } from '../../../Service/me-user-profile.service';
import { StorageType } from "../../../Service/Interfaces/storage-type.enum";
// Decimal Format for integer values displayed in tera datatable.
const DECIMAL_FORMAT: (v: any) => any = (v: number) => v.toFixed(2);
//  ~ End  -------------------------------------------------------------------------------------------------

// -------------------  Component & Class Definition - Start -----------------------------------------------

@Component({
  selector: 'app-me-payment-history',
  templateUrl: './me-payment-history.component.html',
  styleUrls: ['./me-payment-history.component.css']
})
export class MePaymentHistoryComponent implements OnInit {
 
  // -- @details : Class variable declaration ###################################################################
  //  ~ Start - variable declaration _____________________________________________________________________________

  // Class Local variables
 // All variables used within the class must be private

  @Input() setCustNumObj: any;
  private _customerDetails_obj   : any;
  private getRequestInput        : any = "";
  private _userLogin             : any;
  private _userProfileData       : any;
  private postRequestCustomerObject: any =
  {
    records: [{
 
        owner_id: null,
        customer_number: null,
       
     
    }]
  };

  // Local Variables
  showNoRecords         :boolean=true;
  showLoader   : boolean = true;

  _CustomerPaymentList  :any=[];
  customer_number_param : any     = "";

  //Url Variabes
  public id:any;
  public source:string;

  // Tera DataTable Local Fields
  filteredData: any[] = [];
  filteredTotal: number = 0;
  searchTerm: string = '';
  fromRow: number = 1;
  currentPage: number = 1;
  pageSize: number = 50;
  sortBy: string = 'user_name';
  selectedRows: any[] = [];
  sortOrder: TdDataTableSortingOrder = TdDataTableSortingOrder.Ascending;

// Tera DataTable Set Column name/Label and other features.
columns: ITdDataTableColumn[] = [
  { name: 'user_name', label: 'Agent Name', filter: true, sortable: true, width: 200 },
  { name: 'payment_remarks', label: 'Payment Type', sortable: true, filter: true , width: 200},
  { name: 'payment_amount', label: 'Payment Amount', filter: true, sortable: true, width: 200, numeric: true, format: DECIMAL_FORMAT },
  { name: 'payment_date', label: 'Payment Date', sortable: true, filter: true, width: 350 },
  ]; 
//  ~ End  - variable declaration _______________________________________________________________________________

// --  @details :  constructor #############################################################################
//  ~ Start -constructor ------------------------------------------------------------------------------------
  constructor(
    public  callHttpGet                      : MeCallHttpGetService,
    private customerDetailsPersistenceService: PersistenceService,
    public  userProfileService               : MeUserProfileService,
    public  route                            : ActivatedRoute,
    private _dataTableService: TdDataTableService


  ) { 

    this.customer_number_param = +this.route.snapshot.params["id"];
  }

//  ~ End -constructor  --------------------------------------------------------------------------------------

  // --  @details :  ngOnChanges ##################################################################################
  //  ~ Start -ngOnChanges  ---------------------------------------------------------------------------------------
  // ngOnChanges get updated customerNumber
  
    ngOnChanges(setCustNumObj:any) {
      // console.log('on change',this.setCustNumObj);
      this.customer_number_param = this.setCustNumObj;
      this.filteredData = [];
      this.filteredTotal = 0;
      this.ngOnInit();
    }
    
  //  ~ End -ngOnChanges  ---------------------------------------------------------------------------------------


  // --  @details :  ngOnInit ##################################################################################
  //  ~ Start -ngOnInit  ---------------------------------------------------------------------------------------
  ngOnInit() {

        //initialize loader
        this.showLoader    = true;
        this.showNoRecords = false;    

      // Fetch the User Login Details Stored in the Cache
      this._userLogin = this.customerDetailsPersistenceService.get(
        "userLogin",
        StorageType.SESSION
      );
      console.warn("----------------- User Login ----------------- ");
      console.dir(this._userLogin);
   // make call to get user profile details
 //  ~ Start  -------------------------------------------------------------------------------------------------
 this.userProfileService
 .makeRequest_UserProfile(this._userLogin)
 .subscribe(response => {
   this._userProfileData = response;

   console.warn(
     "----------------- User Profile Response payment ----------------- "
   );
   console.log(this._userProfileData);
   console.log(this._userProfileData.ownerDetails);

 });
// ~ End  -------------------------------------------------------------------------------------------------


  if(this.setCustNumObj) {

    this.customer_number_param = this.setCustNumObj;
    console.log('this.customer_number_param',this.customer_number_param);

  }
  else 
  {
    this.route.queryParams.subscribe(params => {
      this.id = params["id"];
      this.source = params["Source"];
      });
      
      
      this.customer_number_param = +this.id;
      
    // this.postRequestCustomerObject.records[0].customer_number =this.customer_number_param;
    console.log('postRequestCustomerObject payment',this.postRequestCustomerObject);      

  }

// initialize 
this.postRequestCustomerObject.records[0].owner_id = this._userProfileData.ownerDetails.owner_id;
this.postRequestCustomerObject.records[0].customer_number =this.customer_number_param;
console.log('postRequestCustomerObject payment',this.postRequestCustomerObject);




// Subscribing to get GetCustomerPayments
this.callHttpGet.makeRequest_GetCustomerPayments(this.postRequestCustomerObject).subscribe(response => {
  console.log(
    "%c Subscription List ***** ----------------------------------------------------------- ",
    "background: #ff5722;font-weight: bold;color: white; "
  );

  this._CustomerPaymentList = response.customerPaymentsList;
  if (this._CustomerPaymentList.length > 0) {
    
  
    // console.log('areaList:',this._CustomerPaymentList);

    this.filteredData=this._CustomerPaymentList;
    this.filteredTotal = this._CustomerPaymentList.length;
    this.filter();
    this.showNoRecords=false;
    this.showLoader = false;

  } else {
    this.showLoader    = false;
    this.showNoRecords = true;
  }

});
// makeRequest_GetCustomerPayments() ~ End  ----------------------------------------------------------------------------------------

  
  }

   //  ~ End -ngOnInit  -------------------------------------------------------------------------------------
  
   // --  @details :  Class Functions for the Component #######################################################
  //  ~ Start  -------------------------------------------------------------------------------------------------

  sort(sortEvent: ITdDataTableSortChangeEvent): void {
    this.sortBy = sortEvent.name;
    this.sortOrder = sortEvent.order;
    this.filter();
    
  }

  search(searchTerm: string): void {
    this.searchTerm = searchTerm;
    this.filter();
  }

  page(pagingEvent: IPageChangeEvent): void {
    this.fromRow = pagingEvent.fromRow;
    this.currentPage = pagingEvent.page;
    this.pageSize = pagingEvent.pageSize;
    this.filter();
  }

  filter(): void { 
    let newData: any[] = this._CustomerPaymentList;
    let excludedColumns: string[] = this.columns
    .filter((column: ITdDataTableColumn) => {
      return ((column.filter === undefined && column.hidden === true) ||
              (column.filter !== undefined && column.filter === false));
    }).map((column: ITdDataTableColumn) => {
      return column.name;
    });
    newData = this._dataTableService.filterData(newData, this.searchTerm, true, excludedColumns);
    this.filteredTotal = newData.length;
    newData = this._dataTableService.sortData(newData, this.sortBy, this.sortOrder);
    newData = this._dataTableService.pageData(newData, this.fromRow, this.currentPage * this.pageSize);
    this.filteredData = newData;
  }

  // ~ End -----------------------------------------------------------------------------------------

}
// -------------------  Component & Class Definition - Start ---------------------------------------------
 