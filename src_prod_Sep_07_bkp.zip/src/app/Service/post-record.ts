export class PostRecord {

    records:any = [];

    constructor(p_input_array:any) {
        this.records[0] = p_input_array;
    }
}
